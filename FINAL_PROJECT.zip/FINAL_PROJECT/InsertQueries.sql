 
INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress,ExpiryDate) VALUES ('Premier League','Gary HoffMan','Brunel building London', Null);   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','John Bentley','Brunel building London', '06-06-1910');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','Arthur Drewry','Brunel building London', '06-06-1955');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','John Mckenna','Brunel building London', '06-06-1936');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','Jack Dunnett','Brunel building London', '06-06-1989');   

  

INSERT INTO Organising_Committee (CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','Philip Carter','Brunel building London', '06-06-2008');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','Will Cuff','Brunel building London', '06-06-2020');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','William westwood','Brunel building London', '06-06-2000');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','William Mcgregor','Brunel building London', '06-06-1995');   

  

INSERT INTO Organising_Committee ( CommitteeName, CommitteePresident,OfficeAddress, ExpiryDate) VALUES ('Premier League','Michel Platini','Brunel building London', '06-06-2005');   

 

 

 

INSERT INTO Sponsorer ( Name, BrandName, ExpiryDate) VALUES ('Ahmed bin Saeed','Emirates', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Molson Coors','Carling brewery', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Barry rodrigues','BarclayCard', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('CS Venkatakrishnan','Barclays', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Tony Douglas','Etihad airways', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Stephen Squeri','American express', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Bill winters','Standard Chartered', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Anthony werkman','Betway', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Fengqing feng','Lotus', Null);   

INSERT INTO Sponsorer (Name, BrandName, ExpiryDate) VALUES ('Oliver steil','TeamViewer', Null);   

 

 

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Ethihad Stadium', 'Ethihad Stadium Manchester', 76900, 55097 ,'Desso GrassMaster');  

  

INSERT INTO Venue( VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Anfield Stadium', 'Anfield Stadium Liver Pool', 7140, 53394 ,'GrassMaster');  

  

  

INSERT INTO Venue( VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Stamford Bridge', 'Fulham', 74282, 41837 ,'GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Tottenhum Stadium', 'Tottenhum London', 70457, 62850 ,'Desso GrassMaster');  

  

INSERT INTO Venue( VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Emirates Stadium', 'Highbury House', 11808, 60260 ,'GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('London Stadium', 'Olympic Park', 14191, 80000 ,'GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Old trafford stadium', 'trafford', 43560, 74140 ,'Desso GrassMaster');  

  

INSERT INTO Venue( VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('The Den Stadium', 'New Cross', 45637, 20146 ,'SISGrass');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('King Power Stadium', 'Filbert Way', 56743, 32261 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Selhurst Stadium', 'selhurst Park', 65475, 25486 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('American Express', 'Falmer', 56478, 31800 ,'Grass');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Villa Park Stadium', 'Birminghan', 74587, 42095 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Brentford Stadium', 'Brentford', 56475, 17250 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ( 'Saint Mary Stadium', 'Southampton', 56435, 32384 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('St James Park', 'Newcastle Upon', 46732, 52305 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Elland Road', 'Leeds', 67437, 37792 ,'GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Goodison Park', 'Goodison Road Walton', 74583, 39414 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Tuft Moor', 'Burnley Lancashire', 47832, 21944 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Vicarage Road', 'Vicarage Road Walford', 45883, 22200 ,'Desso GrassMaster');  

  

INSERT INTO Venue(VenueName, VenueAddress, Field_size, Capacity, Surface_type)  

VALUES ('Carrow Road Stadium', 'Norwich', 87362, 27359 ,'Desso GrassMaster');  

  

 

 

 

 

 INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (50,'Man City', 1, 'Manchester', 'Ethihad Stadium', '9987654321');  

  

INSERT INTO Team( VenueID, Name, Rank, City, Address, Contact)  

VALUES (51, 'LiverPool', 2, 'LiverPool City', 'Anfield Stadium', '9987654322');  

  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (52, 'Chlesea', 3, 'Fulham London', 'Fulham', '9987654323');  

  

  

INSERT INTO Team( VenueID, Name, Rank, City, Address, Contact)  

VALUES (53, 'Tottenham', 4, 'Tottenham City', 'Tottenhum London', '9987654324');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (54, 'Arsenal', 5, 'Islington', 'Highbury House', '9987654325');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (55, 'West Ham', 6, 'Stratford', 'Olympic Park', '9987654326');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (56, 'Man United', 7, 'Manchester', 'trafford', '9987654327');  

  

INSERT INTO Team( VenueID, Name, Rank, City, Address, Contact)  

VALUES (57, 'Wolves', 8, 'Wolverhampton', 'New Cross', '9987654328');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (58, 'Leciester City', 9, 'Leciester', 'Filbert Way', '9987654329');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (59, 'Crystal Palace', 10, 'London', 'selhurst Park', '9987654320');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (60, 'Brighton', 11, 'Brighton', 'Falmer', '9987654311');  

  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (61, 'Aston Villa', 12, 'Birmingham', 'Birminghan UK', '9987654312');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (62, 'BrentFord', 13, 'West London', 'Brentford', '9987654313');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (63, 'Southampton', 14, 'Southampton UK', 'Southampton', '9987654314');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (64, 'Newcastle', 15, 'Newcastle', 'Newcastle Upon', '9987654315');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (65, 'Leeds United', 16, 'Leeds City', 'Leeds', '9987654316');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (66, 'Everton', 17, 'LiverPool', 'Goodison Road Walton', '9987654317');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (67, 'Burnley', 18, 'Burnley', 'Burnley Lancashire', '9987654318');  

  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (68, 'Watford', 19, 'Hertfordshire', 'Vicarage Road Walford', '9987654319');  

  

INSERT INTO Team(VenueID, Name, Rank, City, Address, Contact)  

VALUES (69, 'Norwich City', 20, 'Norwich', 'Norwich', '9987654300');  

  

 

 

INSERT INTO Coach( TeamID,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality,ExpiryDate) VALUES (1001,'Man City', 'Pep Guardiola','9988776655', '05-10-2005','06-10-2022','Spain', NULL);   

  

  

INSERT INTO Coach(TeamID,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1002,'LiverPool', 'Jurgen Klopp','9988776677', '05-10-2006','06-11-2022','Germany', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1003,'Chelsea', 'Thomas Tuchel','9988776699', '05-10-2007','06-01-2022','Germany', NULL);   

  

  

INSERT INTO Coach(TeamID,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1004,'Tottenham', 'Antonio Conte','9988776600', '05-10-2008','06-05-2022','Italy', NULL);   

  

  

INSERT INTO Coach(TeamID,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1005,'Arsenal', 'Mikel Arteta','9988776633', '05-10-2009','06-10-2023','Spain', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1006,'West Ham', 'David William Moyes','9988776688', '05-12-2005','06-11-2023','Scotland', NULL);   

  

  

INSERT INTO Coach( TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1007,'Man United', 'Ralph rangnick','9988776000', '05-01-2006','06-12-2024','Germany', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1008,'Wolves', 'Bruno Lage','9988776644', '05-11-2020','06-05-2024','Portugal', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1009,'Leciseter city', 'Brendan Rodgers','9988776611', '05-06-2018','06-06-2024','Ireland', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1010,'Crystal palace', 'Patrick viera','9988776622', '05-10-2019','06-10-2025','France', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1011,'Brighton', 'Graham stephen porter','9988779320', '05-10-2021','06-10-2026','England', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1012,'Aston villa', 'Steven Gerrard','9988774444', '05-10-2022','06-10-2027','England', NULL);   

  

  

INSERT INTO Coach(TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1013,'BrentFord', 'Thomas frank','9988771111', '05-10-2017','06-01-2022','Netherland', NULL);   

  

  

INSERT INTO Coach( TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1014,'Southampton', 'Ralph Hasenhuttl','9988336655', '05-10-2016','06-04-2022','Austria', NULL);   

  

  

INSERT INTO Coach( TeamID ,TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1015,'New castle', 'Eddie Howe','9985676655', '05-10-2015','06-09-2024','England', NULL);   

  

  

INSERT INTO Coach( TeamID, TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES ( 1016,'Leeds United', 'Jesse Marsch','9981376655', '05-10-2014','06-08-2023','America', NULL);  

INSERT INTO Coach( TeamID, TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES ( 1017,'Everton', 'Frank lampard','9988006655', '05-10-2013','06-03-2022','England', NULL);  

INSERT INTO Coach( TeamID, TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1018,'Burnley', 'Sean mark Dyche','9911776655', '05-10-2012','06-12-2023','England', NULL);  

INSERT INTO Coach( TeamID, TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1019,'Watford', 'Roy Hodgson','9920776655', '05-10-2011','06-11-2024','England', NULL);  

INSERT INTO Coach( TeamID, TeamName, Name, PhoneNumber, Coach_Contract_SD, Coach_Contract_ED,Nationality, ExpiryDate) VALUES (1020,'Norwich city', 'Dean Smith','9218776655', '05-10-2020','06-11-2026','England', NULL);  

 

 

 

 

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1006, 'City Group', '400 Ashton Rd', 'citygroup@gmail.com');      

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1007, 'Fenway Group', 'Boston', 'fenwaygroup@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1008, 'Roman Abramovich', 'Kensington Palace Gardens', 'roman@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1009, 'Joe Lewis', 'London', 'Joe@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1010, 'Korenke Sports', 'Denver', 'korenke@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1011, 'Daniel Kretinsky', 'Brno', 'daniel@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1012, 'Glazer ownership', 'Manchester', 'glazer@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1013, 'Fosun International', 'Wolverhampton', 'fosun@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1014, 'King Power', 'Rangnam Rd', 'kingpower@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1015, 'Steve Parish', 'Forest Hill London', 'steve@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1016, 'Tony Bloom', 'England', 'tony@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1017, 'Wes Edens', 'Montana', 'wes@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1018, 'Matthew Benham', 'Brentford', 'mattew@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1019, 'Sport Republic', 'southampton', 'sportrepublic@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1020, 'PCP Capital', 'London', 'pcpcapital@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1001, 'Aser Group', 'London', 'asergroup@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1002, 'Farhad Moshiri', 'Iran', 'farhad@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1003, 'ALK Capotal', '1330 Avenue NY', 'alk@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1004, 'Gino Pozzo', 'Italy', 'gino@gmail.com');  

  

INSERT INTO Owner(TeamID, OwnerName, OwnerAddress, OwnerEmailID)  

VALUES (1005, 'Delia Smith', 'woking', 'delia@gmail.com');  

  

 

 

 

 

INSERT INTO Player (TeamID,PlayerName,Age,Nationality,Position, Assists_overall, Assists_home,Assists_away, Penalty_goals, Penalty_misses, Yellow_cards_overall, Red_cards_overall, Dominant_leg,Goals_overall,Goals_home,Goals_away)  

VALUES  

( 1006 , 'Aaron Cresswell' , 32 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Aaron Lennon' , 34 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1016 , 'Aaron Mooy' , 31 , 'Australia' , 'Midfielder' , 1 , 0 , 1 , 1 , 0 , 4 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1005 , 'Aaron Ramsey' , 31 , 'Wales' , 'Midfielder' , 6 , 5 , 1 , 0 , 0 , 0 , 0 , 'Right' , 4 , 2 , 2 ),  

( 1016 , 'Aaron Rowe' , 21 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Aaron Wan-Bissaka' , 24 , 'England' , 'Midfielder' , 3 , 1 , 2 , 0 , 0 , 5 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Abdelhamid Sabiri' , 25 , 'Morocco' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Abdoulaye Doucouré' , 29 , 'France' , 'Midfielder' , 6 , 2 , 4 , 0 , 0 , 7 , 0 , 'Right' , 5 , 3 , 2 ),  

( 1018 , 'Aboubakar Kamara' , 26 , 'France' , 'Forward' , 0 , 0 , 0 , 1 , 1 , 2 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1019 , 'Adalberto Peñaranda Maestre' , 24 , 'Venezuela' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1002 , 'Adam David Lallana' , 33 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Adam Masina' , 28 , 'Italy' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1012 , 'Adam Smith' , 30 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 6 , 1 , 'Left' , 1 , 1 , 0 ),  

( 1016 , 'Adama Diakhaby' , 25 , 'France' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Adama Traoré Diarra' , 25 , 'Spain' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1017 , 'Ademola Lookman' , 24 , 'England' , 'Forward' , 2 , 2 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Adrian Mariappa' , 35 , 'Jamaica' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1006 , 'Adrián San Miguel del Castillo' , 35 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Adrien Sebastian Perruchet Silva' , 32 , 'Portugal' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Ainsley Maitland-Niles' , 24 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 3 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1002 , 'Alberto Moreno' , 29 , 'Spain' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Aleksandar Mitrović' , 27 , 'Serbia' , 'Forward' , 3 , 2 , 1 , 1 , 0 , 7 , 0 , 'Right' , 11 , 8 , 3 ),  

( 1005 , 'Alex Iwobi' , 25 , 'Nigeria' , 'Forward' , 6 , 3 , 3 , 0 , 0 , 0 , 0 , 'Left' , 3 , 1 , 2 ),  

( 1014 , 'Alex McCarthy' , 32 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Alex Oxlade-Chamberlain' , 28 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Alex Pritchard' , 28 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1020 , 'Alex Smithies' , 31 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Alexander Sørloth' , 26 , 'Norway' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Alexandre Lacazette' , 30 , 'France' , 'Forward' , 8 , 4 , 4 , 0 , 0 , 2 , 0 , 'Left' , 13 , 9 , 4 ),  

( 1006 , 'Alexandre Nascimento Costa Silva' , 24 , 'Portugal' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'Alexis Sanchez' , 33 , 'Chile' , 'Forward' , 3 , 0 , 3 , 0 , 0 , 3 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1014 , 'Alfie Jones' , 24 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Alfie Mawson' , 27 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Alfie Whiteman' , 23 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Ali Koiki' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Alireza Jahanbakhsh' , 28 , 'Iran' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Alisson Becker' , 29 , 'Brazil' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Alvaro Morata' , 29 , 'Spain' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 5 , 3 , 2 ),  

( 1007 , 'Ander Herrera' , 32 , 'Spain' , 'Midfielder' , 3 , 3 , 0 , 0 , 0 , 4 , 0 , 'Right' , 2 , 0 , 2 ),  

( 1017 , 'André Filipe Tavares Gomes' , 28 , 'Portugal' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 7 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1019 , 'Andre Gray' , 30 , 'England' , 'Forward' , 2 , 2 , 0 , 0 , 0 , 2 , 0 , 'Left' , 7 , 5 , 2 ),  

( 1018 , 'André Schürrle' , 31 , 'Germany' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 6 , 3 , 3 ),  

( 1018 , 'André-Frank Zambo Anguissa' , 26 , 'Cameroon' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 3 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Andreas Christensen' , 25 , 'Denmark' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Andreas Pereira' , 26 , 'Brazil' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1002 , 'Andrew Robertson' , 27 , 'Scotland' , 'Defender' , 11 , 9 , 2 , 0 , 0 , 4 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Andrew Surman' , 35 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1006 , 'Andriy Yarmolenko' , 32 , 'Ukraine' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 2 , 0 , 2 ),  

( 1010 , 'Andros Townsend' , 30 , 'England' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 1 , 0 , 'Left' , 6 , 2 , 4 ),  

( 1006 , 'Andy Carroll' , 33 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Angel Gomes' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Angelo Ogbonna' , 33 , 'Italy' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1014 , 'Angus Gunn' , 25 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Anthony Driscoll-Glennon' , 22 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Anthony Knockaert' , 30 , 'France' , 'Midfielder' , 6 , 5 , 1 , 0 , 0 , 5 , 1 , 'Left' , 2 , 1 , 1 ),  

( 1007 , 'Anthony Martial' , 26 , 'France' , 'Forward' , 2 , 1 , 1 , 1 , 0 , 2 , 0 , 'Right' , 10 , 4 , 6 ),  

( 1015 , 'Antonio Barreca' , 26 , 'Italy' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1003 , 'Antonio Rüdiger' , 28 , 'Germany' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 7 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1007 , 'Antonio Valencia' , 36 , 'Ecuador' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Arijanet Muric' , 23 , 'Montenegro' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Aron Einar Gunnarsson' , 32 , 'Iceland' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1006 , 'Arthur Masuaku' , 28 , 'France' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Artur Boruc' , 41 , 'Poland' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Ashley Barnes' , 32 , 'England' , 'Forward' , 2 , 1 , 1 , 2 , 0 , 8 , 0 , 'Right' , 12 , 6 , 6 ),  

( 1013 , 'Ashley Westwood' , 31 , 'England' , 'Midfielder' , 7 , 2 , 5 , 0 , 0 , 5 , 0 , 'Left' , 2 , 0 , 2 ),  

( 1007 , 'Ashley Young' , 36 , 'England' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 10 , 1 , 'Left' , 2 , 1 , 1 ),  

( 1012 , 'Asmir Begović' , 34 , 'Bosnia' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Aymeric Laporte' , 27 , 'France' , 'Defender' , 3 , 3 , 0 , 0 , 0 , 3 , 0 , 'Right' , 3 , 0 , 3 ),  

( 1015 , 'Ayoze Perez' , 28 , 'Spain' , 'Forward' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Right' , 12 , 9 , 3 ),  

( 1010 , 'Bakary Sako' , 33 , 'Mali' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Bakayo Sako' , 0 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Ben Chilwell' , 25 , 'England' , 'Defender' , 4 , 1 , 3 , 0 , 0 , 4 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Ben Davies' , 28 , 'Wales' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Ben Foster' , 38 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Ben Gibson' , 28 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1016 , 'Ben Hamer' , 34 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Ben Mee' , 32 , 'England' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 9 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Ben White' , 24 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Ben Wilmot' , 22 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Benjamin Johnson' , 21 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Benjamin Mendy' , 27 , 'France' , 'Defender' , 5 , 3 , 2 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Beram Kayal' , 33 , 'Israel' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 4 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1017 , 'Bernard Anício Caldeira Duarte' , 29 , 'Brazil' , 'Midfielder' , 3 , 1 , 2 , 0 , 0 , 5 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1011 , 'Bernardo' , 26 , 'Brazil' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 4 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Bernardo Silva' , 27 , 'Portugal' , 'Midfielder' , 7 , 4 , 3 , 0 , 0 , 3 , 0 , 'Left' , 7 , 2 , 5 ),  

( 1005 , 'Bernd Leno' , 29 , 'Germany' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1020 , 'Bobby Reid' , 28 , 'England' , 'Midfielder' , 2 , 1 , 1 , 1 , 0 , 0 , 0 , 'Left' , 5 , 4 , 1 ),  

( 1020 , 'Brian Murphy' , 38 , 'Republic of Ireland' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Bright Enobakhare' , 23 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1020 , 'Bruno Écuélé Manga' , 33 , 'Gabon' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Bruno Saltor Grau' , 41 , 'Spain' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Caglar Söyüncü' , 25 , 'Turkey' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Callum Hudson-Odoi' , 21 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Callum Paterson' , 27 , 'Scotland' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Right' , 4 , 3 , 1 ),  

( 1015 , 'Callum Roberts' , 24 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1014 , 'Callum Slattery' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Callum Wilson' , 29 , 'England' , 'Forward' , 9 , 4 , 5 , 1 , 1 , 3 , 0 , 'Left' , 14 , 5 , 9 ),  

( 1018 , 'Calum Chambers' , 26 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 9 , 0 , 'Left' , 2 , 2 , 0 ),  

( 1008 , 'Cameron John' , 22 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Carl Jenkinson' , 29 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Carlos Sánchez' , 35 , 'Colombia' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1014 , 'Cedric Soares' , 30 , 'Portugal' , 'Defender' , 2 , 0 , 2 , 0 , 0 , 4 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1017 , 'Cenk Tosun' , 30 , 'Turkey' , 'Forward' , 3 , 1 , 2 , 0 , 0 , 3 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1003 , 'Cesar Azpilicueta' , 32 , 'Spain' , 'Defender' , 5 , 3 , 2 , 0 , 0 , 4 , 0 , 'Left' , 1 , 0 , 1 ), 

( 1003 , 'Cesc Fabregas' , 34 , 'Spain' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Charlie Austin' , 32 , 'England' , 'Forward' , 2 , 1 , 1 , 0 , 1 , 1 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1012 , 'Charlie Daniels' , 35 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1013 , 'Charlie Taylor' , 28 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Cheikhou Kouyaté' , 32 , 'Senegal' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Chris Löwe' , 32 , 'Germany' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1012 , 'Chris Mepham' , 24 , 'Wales' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Chris Smalling' , 32 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1013 , 'Chris Wood' , 30 , 'New Zealand' , 'Forward' , 2 , 0 , 2 , 0 , 0 , 2 , 0 , 'Right' , 10 , 4 , 6 ),  

( 1015 , 'Christian Atsu Twasam' , 30 , 'Ghana' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1010 , 'Christian Benteke' , 31 , 'Belgium' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1004 , 'Christian Eriksen' , 29 , 'Denmark' , 'Midfielder' , 12 , 8 , 4 , 0 , 0 , 3 , 0 , 'Left' , 8 , 6 , 2 ),  

( 1009 , 'Christian Fuchs' , 35 , 'Austria' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Christian Kabasele' , 30 , 'Belgium' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Christopher Schindler' , 31 , 'Germany' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 6 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1015 , 'Ciaran Clark' , 32 , 'Republic of Ireland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1001 , 'Claudio Andrés Bravo Muñoz' , 38 , 'Chile' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Collin Quaner' , 30 , 'Germany' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Connor Wickham' , 28 , 'England' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1008 , 'Conor Coady' , 28 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1006 , 'Conor Coventry' , 21 , 'Republic of Ireland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Craig Cathcart' , 32 , 'Northern Ireland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1002 , 'Curtis Jones' , 20 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Cyrus Christie' , 29 , 'Republic of Ireland' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 7 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Dale Stephens' , 32 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 7 , 1 , 'Left' , 1 , 0 , 1 ),  

( 1005 , 'Damián Emiliano Martínez' , 29 , 'Argentina' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Dan Burn' , 29 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Dan Gosling' , 31 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 8 , 0 , 'Right' , 2 , 0 , 2 ),  

( 1009 , 'Daniel Amartey' , 27 , 'Ghana' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Daniel Sturridge' , 32 , 'England' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1014 , 'Daniel William John Ings' , 29 , 'England' , 'Forward' , 3 , 3 , 0 , 3 , 0 , 1 , 0 , 'Left' , 7 , 3 , 4 ),  

( 1016 , 'Daniel Williams' , 32 , 'USA' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'Danilo' , 30 , 'Brazil' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1003 , 'Danny Drinkwater' , 31 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Danny Rose' , 31 , 'England' , 'Defender' , 3 , 1 , 2 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Danny Simpson' , 35 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Danny Ward' , 28 , 'Wales' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Danny Ward' , 31 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1005 , 'Danny Welbeck' , 31 , 'England' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1019 , 'Daryl Janmaat' , 32 , 'Netherlands' , 'Defender' , 2 , 2 , 0 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'David Brooks' , 24 , 'England' , 'Forward' , 5 , 3 , 2 , 0 , 0 , 3 , 0 , 'Left' , 7 , 4 , 3 ),  

( 1011 , 'David Button' , 32 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'David de Gea' , 31 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'David Junior Hoilett' , 31 , 'Canada' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1003 , 'David Luiz' , 34 , 'Brazil' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 3 , 0 , 'Right' , 3 , 3 , 0 ),  

( 1001 , 'David Silva' , 36 , 'Spain' , 'Midfielder' , 8 , 3 , 5 , 0 , 0 , 3 , 0 , 'Right' , 6 , 4 , 2 ),  

( 1003 , 'Davide Zappacosta' , 29 , 'Italy' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Davinson Sánchez Mina' , 25 , 'Colombia' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1011 , 'Davy Pröpper' , 30 , 'Netherlands' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1015 , 'DeAndre Yedlin' , 28 , 'USA' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 7 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1006 , 'Declan Rice' , 23 , 'Republic of Ireland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1002 , 'Dejan Lovren' , 32 , 'Croatia' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1004 , 'Dele Alli' , 25 , 'England' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 4 , 0 , 'Left' , 5 , 1 , 4 ),  

( 1009 , 'Demarai Gray' , 25 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Left' , 4 , 1 , 3 ),  

( 1016 , 'Demeaco Duhaney' , 23 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1018 , 'Denis Odoi' , 33 , 'Belgium' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Denis Suárez' , 28 , 'Spain' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Diego Rico' , 28 , 'Spain' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Diogo José Teixeira da Silva' , 25 , 'Portugal' , 'Midfielder' , 5 , 3 , 2 , 0 , 0 , 11 , 0 , 'Left' , 9 , 7 , 2 ),  

( 1002 , 'Divock Origi' , 26 , 'Belgium' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1019 , 'Domingos Quina' , 22 , 'Portugal' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1017 , 'Dominic Calvert-Lewin' , 24 , 'England' , 'Forward' , 2 , 2 , 0 , 0 , 0 , 3 , 0 , 'Left' , 6 , 3 , 3 ),  

( 1012 , 'Dominic Solanke' , 24 , 'England' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Dwight McNeil' , 22 , 'England' , 'Forward' , 5 , 3 , 2 , 0 , 0 , 2 , 0 , 'Right' , 3 , 3 , 0 ),  

( 1003 , 'Eden Hazard' , 31 , 'Belgium' , 'Midfielder' , 15 , 10 , 5 , 4 , 0 , 2 , 0 , 'Right' , 16 , 11 , 5 ),  

( 1001 , 'Ederson' , 28 , 'Brazil' , 'Goalkeeper' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Edward Nketiah' , 22 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1016 , 'Elias Kachunga' , 29 , 'Congo DR' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1012 , 'Emerson Hyndman' , 25 , 'USA' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Emerson Palmieri dos Santos' , 27 , 'Italy' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Emile Smith Rowe' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Eric Bertrand Bailly' , 27 , 'Côte  dIvoire' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 1 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Eric Dier' , 27 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1016 , 'Erik Durm' , 29 , 'Germany' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Erik Lamela' , 29 , 'Argentina' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Left' , 4 , 1 , 3 ),  

( 1003 , 'Ethan Ampadu' , 21 , 'Wales' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Etienne Capoue' , 33 , 'France' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 15 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1006 , 'Fabián Cornelio Balbuena González' , 30 , 'Paraguay' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1001 , 'Fabian Delph' , 32 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 2 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1015 , 'Fabian Schär' , 30 , 'Switzerland' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 12 , 0 , 'Left' , 4 , 3 , 1 ),  

( 1002 , 'Fabinho' , 28 , 'Brazil' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 6 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1018 , 'Fabricio Martín Agosto Ramírez' , 34 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Faustino Marcos Alberto Rojo' , 31 , 'Argentina' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Federico Fernández' , 32 , 'Argentina' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Felipe Anderson Pereira Gomes' , 28 , 'Brazil' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 3 , 0 , 'Left' , 9 , 4 , 5 ),  

( 1004 , 'Fernando Llorente Torres' , 36 , 'Spain' , 'Forward' , 4 , 4 , 0 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1001 , 'Fernando Luiz Rosa' , 36 , 'Brazil' , 'Midfielder' , 3 , 3 , 0 , 0 , 0 , 5 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1016 , 'Florent Hadergjonaj' , 27 , 'Switzerland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Florian Lejeune' , 30 , 'France' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Florin Andone' , 28 , 'Romania' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 5 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1018 , 'Floyd Ayité' , 33 , 'Togo' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1009 , 'Fousseni Diabaté' , 26 , 'Mali' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Francisco Femenía Far' , 30 , 'Spain' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1014 , 'Fraser Forster' , 33 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Freddie Woodman' , 24 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Frederico Rodrigues Santos' , 28 , 'Brazil' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1001 , 'Gabriel Jesus' , 24 , 'Brazil' , 'Forward' , 3 , 1 , 2 , 1 , 0 , 1 , 0 , 'Left' , 7 , 5 , 2 ),  

( 1011 , 'Gaëtan Bong Songo' , 33 , 'Cameroon' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Gary Cahill' , 36 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Gary Madine' , 31 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'George Marsh' , 23 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Georges-Kevin N Koudou Mbida' , 26 , 'France' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1002 , 'Georginio Wijnaldum' , 31 , 'Netherlands' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 3 , 1 , 2 ),  

( 1019 , 'Gerard Deulofeu' , 27 , 'Spain' , 'Forward' , 5 , 3 , 2 , 0 , 0 , 3 , 0 , 'Left' , 10 , 3 , 7 ),  

( 1011 , 'Glenn Murray' , 38 , 'England' , 'Forward' , 1 , 1 , 0 , 4 , 0 , 5 , 0 , 'Left' , 13 , 8 , 5 ),  

( 1003 , 'Gonzalo Higuain' , 34 , 'Argentina' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 5 , 4 , 1 ),  

( 1006 , 'Grady Diangana' , 23 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Granit Xhaka' , 29 , 'Switzerland' , 'Midfielder' , 2 , 0 , 2 , 0 , 0 , 10 , 0 , 'Right' , 4 , 2 , 2 ),  

( 1020 , 'Greg Cunningham' , 30 , 'Republic of Ireland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1017 , 'Gylfi Sigurdsson' , 32 , 'Iceland' , 'Midfielder' , 6 , 2 , 4 , 2 , 3 , 3 , 0 , 'Left' , 13 , 7 , 6 ),  

( 1009 , 'Hamza Choudhury' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Harry Arter' , 32 , 'Republic of Ireland' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 10 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Harry Kane' , 28 , 'England' , 'Forward' , 4 , 2 , 2 , 4 , 0 , 5 , 0 , 'Right' , 17 , 6 , 11 ),  

( 1009 , 'Harry Maguire' , 28 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 7 , 1 , 'Right' , 3 , 0 , 3 ),  

( 1004 , 'Harry Winks' , 25 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1018 , 'Harvey Elliot' , 0 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Harvey Lewis Barnes' , 24 , 'England' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 0 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1018 , 'Håvard Nordtveit' , 31 , 'Norway' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Hector Bellerin' , 26 , 'Spain' , 'Defender' , 5 , 4 , 1 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Hélder Wander Sousa Azevedo Costa' , 28 , 'Portugal' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 3 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1005 , 'Henrikh Mkhitaryan' , 32 , 'Armenia' , 'Midfielder' , 4 , 3 , 1 , 0 , 0 , 1 , 0 , 'Right' , 6 , 3 , 3 ),  

( 1004 , 'Heung-Min Son' , 29 , 'South Korea' , 'Forward' , 6 , 2 , 4 , 0 , 0 , 3 , 1 , 'Left' , 12 , 8 , 4 ),  

( 1019 , 'Heurelho da Silva Gomes' , 40 , 'Brazil' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Hugo Lloris' , 35 , 'France' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Ibrahima Cissé' , 27 , 'Belgium' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1017 , 'Idrissa Gana Gueye' , 32 , 'Senegal' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 6 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'İlkay Gündoğan' , 31 , 'Germany' , 'Midfielder' , 3 , 0 , 3 , 0 , 0 , 3 , 0 , 'Right' , 6 , 4 , 2 ),  

( 1019 , 'Isaac Ajayi Success' , 26 , 'Nigeria' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1015 , 'Isaac Hayden' , 26 , 'England' , 'Midfielder' , 4 , 4 , 0 , 0 , 0 , 4 , 1 , 'Left' , 1 , 0 , 1 ),  

( 1016 , 'Isaac Mbenza' , 25 , 'Belgium' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1006 , 'Issa Diop' , 25 , 'France' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1008 , 'Ivan Ricardo Neves Abreu Cavaleiro' , 28 , 'Portugal' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1013 , 'Jack Cork' , 32 , 'England' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 6 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1012 , 'Jack Simpson' , 25 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1014 , 'Jack Stephens' , 27 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1006 , 'Jack Wilshere' , 30 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1015 , 'Jacob Murphy' , 26 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Jaïro Riedewald' , 25 , 'Netherlands' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Jamal Lascelles' , 28 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 4 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'James Garner' , 20 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'James Maddison' , 25 , 'England' , 'Midfielder' , 7 , 4 , 3 , 1 , 1 , 5 , 1 , 'Left' , 7 , 3 , 4 ),  

( 1010 , 'James McArthur' , 34 , 'Scotland' , 'Midfielder' , 6 , 1 , 5 , 0 , 0 , 7 , 0 , 'Left' , 3 , 1 , 2 ),  

( 1017 , 'James McCarthy' , 31 , 'Republic of Ireland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'James Milner' , 36 , 'England' , 'Midfielder' , 4 , 2 , 2 , 3 , 0 , 7 , 1 , 'Right' , 5 , 0 , 5 ),  

( 1013 , 'James Tarkowski' , 29 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 8 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1010 , 'James Tomkins' , 32 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 6 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1014 , 'James Ward-Prowse' , 27 , 'England' , 'Midfielder' , 0 , 0 , 0 , 1 , 0 , 4 , 0 , 'Left' , 7 , 5 , 2 ),  

( 1015 , 'Jamie Sterry' , 26 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1009 , 'Jamie Vardy' , 34 , 'England' , 'Forward' , 4 , 3 , 1 , 4 , 1 , 4 , 1 , 'Right' , 18 , 8 , 10 ),  

( 1014 , 'Jan Bednarek' , 25 , 'Poland' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 7 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Jan Vertonghen' , 34 , 'Belgium' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 5 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1014 , 'Jannik Vestergaard' , 29 , 'Denmark' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Jason Puncheon' , 35 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Jason Steele' , 31 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1006 , 'Javier Hernandez' , 33 , 'Mexico' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 7 , 5 , 2 ),  

( 1015 , 'Javier Manquillo Gaitán' , 27 , 'Spain' , 'Defender' , 3 , 2 , 1 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Jayson Molumby' , 22 , 'Republic of Ireland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1020 , 'Jazz Richards' , 30 , 'Wales' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Jean Michaël Seri' , 30 , 'Côte  dIvoire' , 'Midfielder' , 2 , 0 , 2 , 0 , 0 , 6 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1013 , 'Jeff Hendrick' , 29 , 'Republic of Ireland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 3 , 1 , 2 ),  

( 1012 , 'Jefferson Lerma' , 27 , 'Colombia' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 12 , 0 , 'Left' , 2 , 0 , 2 ),  

( 1010 , 'Jeffrey Schlupp' , 29 , 'Ghana' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 4 , 1 , 3 ),  

( 1012 , 'Jermain Defoe' , 39 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Jesse Lingard' , 29 , 'England' , 'Midfielder' , 2 , 1 , 1 , 1 , 0 , 3 , 0 , 'Right' , 4 , 1 , 3 ),  

( 1008 , 'João Moutinho' , 35 , 'Portugal' , 'Midfielder' , 8 , 5 , 3 , 0 , 0 , 4 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1020 , 'Joe Bennett' , 31 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1018 , 'Joe Bryan' , 28 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Joe Daniel Tupper' , 24 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1002 , 'Joe Gomez' , 24 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Joe Hart' , 34 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Joe Powell' , 23 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Joe Ralls' , 28 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 1 , 5 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Joel Coleman' , 26 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Joel Matip' , 30 , 'Cameroon' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1010 , 'Joel Ward' , 32 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1013 , 'Johann Berg Guðmundsson' , 31 , 'Iceland' , 'Midfielder' , 6 , 5 , 1 , 0 , 0 , 2 , 0 , 'Left' , 3 , 0 , 3 ),  

( 1008 , 'John Ruddy' , 35 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'John Stones' , 27 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Jon Gorenc Stankovič' , 26 , 'Slovenia' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1016 , 'Jonas Lössl' , 32 , 'Denmark' , 'Goalkeeper' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Jonathan Hogg' , 33 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 9 , 1 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Jonathan Walters' , 38 , 'Republic of Ireland' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1015 , 'Jonjo Shelvey' , 29 , 'England' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1017 , 'Jonjoe Kenny' , 24 , 'England' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Jonny' , 27 , 'Spain' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 6 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1009 , 'Jonny Evans' , 34 , 'Northern Ireland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1010 , 'Jordan Ayew' , 30 , 'Ghana' , 'Forward' , 2 , 0 , 2 , 0 , 0 , 3 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1002 , 'Jordan Henderson' , 31 , 'England' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 3 , 1 , 'Left' , 1 , 0 , 1 ),  

( 1017 , 'Jordan Pickford' , 27 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Jordon Ibe' , 26 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1003 , 'Jorginho' , 30 , 'Italy' , 'Midfielder' , 0 , 0 , 0 , 1 , 0 , 8 , 0 , 'Right' , 2 , 0 , 2 ),  

( 1007 , 'José Diogo Dalot Teixeira' , 22 , 'Portugal' , 'Defender' , 2 , 2 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'José Holebas' , 37 , 'Greece' , 'Defender' , 6 , 5 , 1 , 0 , 0 , 13 , 1 , 'Left' , 3 , 2 , 1 ),  

( 1011 , 'Jose Izquierdo' , 29 , 'Colombia' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1015 , 'José Luis Sanmartín Mato' , 31 , 'Spain' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1005 , 'Joseph Willock' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Josh Benson' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'Josh Knight' , 24 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Josh Murphy' , 26 , 'England' , 'Forward' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1012 , 'Joshua King' , 29 , 'Norway' , 'Forward' , 3 , 3 , 0 , 5 , 1 , 3 , 0 , 'Left' , 12 , 9 , 3 ),  

( 1014 , 'Joshua Sims' , 24 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Juan Marcos Foyth' , 24 , 'Argentina' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 1 , 'Right' , 1 , 0 , 1 ),  

( 1007 , 'Juan Mata' , 33 , 'Spain' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 3 , 0 , 'Right' , 3 , 3 , 0 ),  

( 1010 , 'Julián Speroni' , 42 , 'Argentina' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Juninho Bacuna' , 24 , 'Netherlands' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1012 , 'Junior Stanislas' , 32 , 'England' , 'Midfielder' , 3 , 3 , 0 , 1 , 0 , 1 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1011 , 'Jürgen Locadia' , 28 , 'Netherlands' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1020 , 'Kadeem Harris' , 28 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1015 , 'Karl Darlow' , 31 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Karlan Ahearne-Grant' , 24 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 4 , 2 , 2 ),  

( 1009 , 'Kasper Schmeichel' , 35 , 'Denmark' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Kayne Ramsey' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Kazaiah Sterling' , 23 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'Kelechi Iheanacho' , 25 , 'Nigeria' , 'Forward' , 3 , 2 , 1 , 0 , 0 , 2 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1015 , 'Kelland Watts' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Ken Sema' , 28 , 'Sweden' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 1 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1020 , 'Kenneth Dahrup Zohorè' , 27 , 'Denmark' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1003 , 'Kepa Arrizabalaga' , 27 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Kevin De Bruyne' , 30 , 'Belgium' , 'Midfielder' , 2 , 0 , 2 , 0 , 0 , 2 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1013 , 'Kevin Long' , 31 , 'Republic of Ireland' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Kevin McDonald' , 33 , 'Scotland' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 6 , 1 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Kieran Dowell' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Kieran Trippier' , 31 , 'England' , 'Defender' , 3 , 0 , 3 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1005 , 'Konstantinos Mavropanos' , 24 , 'Greece' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1008 , 'Kortney Hause' , 26 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Kurt Zouma' , 27 , 'France' , 'Defender' , 2 , 0 , 2 , 0 , 0 , 5 , 1 , 'Right' , 2 , 1 , 1 ),  

( 1012 , 'Kyle Taylor' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'Kyle Walker' , 31 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 3 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1004 , 'Kyle Walker-Peters' , 24 , 'England' , 'Defender' , 3 , 3 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Laurent Depoitre' , 33 , 'Belgium' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Laurent Koscielny' , 36 , 'France' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1018 , 'Lazar Marković' , 27 , 'Serbia' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Leander Dendoncker' , 26 , 'Belgium' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1020 , 'Leandro Bacuna' , 30 , 'Curaçao' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Lee Grant' , 38 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Lee Peltier' , 35 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1017 , 'Leighton Baines' , 37 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Leon Balogun' , 33 , 'Nigeria' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1008 , 'Leonardo Bonatini Lohner Maia' , 27 , 'Brazil' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'Leroy Sané' , 26 , 'Germany' , 'Midfielder' , 10 , 6 , 4 , 0 , 0 , 1 , 0 , 'Right' , 10 , 5 , 5 ),  

( 1015 , 'Lewis Cass' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Lewis Cook' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Lewis Dunk' , 30 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 7 , 1 , 'Left' , 2 , 0 , 2 ),  

( 1020 , 'Loïc Damour' , 31 , 'France' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Loris Karius' , 28 , 'Germany' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Luca de la Torre' , 23 , 'USA' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Lucas Digne' , 28 , 'France' , 'Defender' , 4 , 2 , 2 , 0 , 0 , 6 , 1 , 'Right' , 4 , 2 , 2 ),  

( 1006 , 'Lucas Perez' , 33 , 'Spain' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 3 , 3 , 0 ),  

( 1004 , 'Lucas Rodrigues Moura da Silva' , 29 , 'Brazil' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 10 , 6 , 4 ),  

( 1005 , 'Lucas Torreira' , 25 , 'Uruguay' , 'Midfielder' , 2 , 0 , 2 , 0 , 0 , 8 , 1 , 'Left' , 2 , 2 , 0 ),  

( 1018 , 'Luciano Vietto' , 28 , 'Argentina' , 'Forward' , 4 , 4 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1010 , 'Luka Milivojević' , 30 , 'Serbia' , 'Midfielder' , 2 , 0 , 2 , 10 , 1 , 10 , 0 , 'Right' , 12 , 7 , 5 ),  

( 1004 , 'Luke Amos' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Luke Dreher' , 23 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'Luke Shaw' , 26 , 'England' , 'Defender' , 4 , 2 , 2 , 0 , 0 , 11 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1012 , 'Lys Mousset' , 25 , 'France' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1017 , 'Maarten Stekelenburg' , 39 , 'Netherlands' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Mamadou Sakho' , 31 , 'France' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1014 , 'Manolo Gabbiadini' , 30 , 'Italy' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1006 , 'Manuel Lanzini' , 28 , 'Argentina' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1009 , 'Marc Albrighton' , 32 , 'England' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 3 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1003 , 'Marc Guehi' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Marc Navarro Ceciliano' , 26 , 'Spain' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1012 , 'Marc Pugh' , 34 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1003 , 'Marcos Alonso' , 31 , 'Spain' , 'Defender' , 4 , 3 , 1 , 0 , 0 , 6 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1018 , 'Marcus Bettinelli' , 29 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Marcus Rashford' , 24 , 'England' , 'Forward' , 6 , 3 , 3 , 0 , 0 , 4 , 1 , 'Left' , 10 , 4 , 6 ),  

( 1014 , 'Mario Lemina' , 28 , 'Gabon' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 5 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1006 , 'Mark Noble' , 34 , 'England' , 'Midfielder' , 5 , 4 , 1 , 4 , 0 , 7 , 1 , 'Left' , 5 , 2 , 3 ),  

( 1012 , 'Mark Travers' , 22 , 'Republic of Ireland' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Marko Arnautović' , 32 , 'Austria' , 'Forward' , 4 , 1 , 3 , 1 , 0 , 3 , 0 , 'Right' , 10 , 7 , 3 ),  

( 1011 , 'Markus Suttner' , 34 , 'Austria' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Marouane Fellaini' , 34 , 'Belgium' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1015 , 'Martin Dúbravka' , 32 , 'Slovakia' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Martin Kelly' , 31 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Martín Montoya' , 30 , 'Spain' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Mason Greenwood' , 20 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Mason Holgate' , 25 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Matěj Vydra' , 29 , 'Czech Republic' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1003 , 'Mateo Kovačić' , 27 , 'Croatia' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Mathew Ryan' , 29 , 'Australia' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Mathias Jattah-Njie Jørgensen' , 31 , 'Denmark' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 6 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1012 , 'Matt Butcher' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Matt Doherty' , 29 , 'Republic of Ireland' , 'Defender' , 5 , 4 , 1 , 0 , 0 , 5 , 0 , 'Left' , 4 , 1 , 3 ),  

( 1015 , 'Matt Ritchie' , 32 , 'Scotland' , 'Midfielder' , 8 , 2 , 6 , 1 , 1 , 9 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1014 , 'Matt Targett' , 26 , 'England' , 'Defender' , 3 , 2 , 1 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1007 , 'Matteo Darmian' , 32 , 'Italy' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Mattéo Guendouzi Olié' , 22 , 'France' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 9 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Matthew Connolly' , 34 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Matthew Lowton' , 32 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 7 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Matty Daly' , 20 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Max Harrison Sanders' , 23 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Max Kilman' , 24 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Max Meyer' , 26 , 'Germany' , 'Midfielder' , 2 , 0 , 2 , 0 , 0 , 3 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1018 , 'Maxime Le Marchand' , 32 , 'France' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Maya Yoshida' , 33 , 'Japan' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Mesut Özil' , 33 , 'Germany' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 2 , 0 , 'Right' , 5 , 4 , 1 ),  

( 1017 , 'Michael Keane' , 29 , 'England' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1014 , 'Michael Obafemi' , 21 , 'Republic of Ireland' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1006 , 'Michail Antonio' , 31 , 'England' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 3 , 0 , 'Left' , 6 , 4 , 2 ),  

( 1004 , 'Michel Vorm' , 38 , 'Netherlands' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Michy Batshuayi' , 28 , 'Belgium' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 5 , 2 , 3 ),  

( 1015 , 'Miguel Ángel Almirón Rejala' , 27 , 'Paraguay' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1019 , 'Miguel Ángel Britos Cabrera' , 36 , 'Uruguay' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Mohamed Diamé' , 34 , 'Senegal' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Mohamed Elneny' , 29 , 'Egypt' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Mohamed Elyounoussi' , 27 , 'Norway' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Mohamed Salah' , 29 , 'Egypt' , 'Forward' , 8 , 5 , 3 , 3 , 0 , 1 , 0 , 'Right' , 22 , 13 , 9 ),  

( 1008 , 'Morgan Gibbs-White' , 21 , 'England' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Morgan Schneiderlin' , 32 , 'France' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Moussa Dembele' , 34 , 'Belgium' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Moussa Sissoko' , 32 , 'France' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'N Golo Kanté' , 30 , 'France' , 'Midfielder' , 4 , 3 , 1 , 0 , 0 , 3 , 0 , 'Left' , 4 , 2 , 2 ),  

( 1002 , 'Naby Deco Keïta' , 26 , 'Guinea' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1005 , 'Nacho Monreal' , 35 , 'Spain' , 'Defender' , 3 , 0 , 3 , 0 , 0 , 5 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1009 , 'Nampalys Mendy' , 29 , 'France' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 5 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Nathan Aké' , 26 , 'Netherlands' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 4 , 3 , 1 ),  

( 1006 , 'Nathan Holland' , 23 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Nathan Redmond' , 27 , 'England' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 3 , 0 , 'Left' , 6 , 4 , 2 ),  

( 1019 , 'Nathaniel Chalobah' , 27 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Nathaniel Clyne' , 30 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1020 , 'Nathaniel Mendez-Laing' , 29 , 'England' , 'Midfielder' , 1 , 1 , 0 , 1 , 0 , 0 , 0 , 'Right' , 4 , 0 , 4 ),  

( 1018 , 'Neeskens Kebano' , 29 , 'Congo DR' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Neil Leonard Dula Etheridge' , 31 , 'Philippines' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'Nemanja Matić' , 33 , 'Serbia' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 8 , 1 , 'Left' , 1 , 1 , 0 ),  

( 1001 , 'Nicolas Otamendi' , 33 , 'Argentina' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Nikola Tavares' , 23 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Nnamdi Ofoborh' , 22 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'Oleksandr Zinchenko' , 25 , 'Ukraine' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Oliver Skipp' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Olivier Giroud' , 35 , 'France' , 'Forward' , 4 , 3 , 1 , 0 , 0 , 1 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1009 , 'Onyinye Wilfred Ndidi' , 25 , 'Nigeria' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 8 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1014 , 'Oriol Romeu' , 30 , 'Spain' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 11 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1020 , 'Oumar Niasse' , 31 , 'Senegal' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Pablo Zabaleta' , 36 , 'Argentina' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 4 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Pape N Diaye Souaré' , 31 , 'Senegal' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1011 , 'Pascal Groß' , 30 , 'Germany' , 'Midfielder' , 3 , 1 , 2 , 1 , 1 , 1 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1010 , 'Patrick van Aanholt' , 31 , 'Netherlands' , 'Defender' , 2 , 0 , 2 , 0 , 0 , 3 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1015 , 'Paul Dummett' , 30 , 'Wales' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Paul Pogba' , 28 , 'France' , 'Midfielder' , 9 , 4 , 5 , 7 , 3 , 6 , 0 , 'Right' , 13 , 10 , 3 ),  

( 1004 , 'Paulo Dino Gazzaniga' , 30 , 'Argentina' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1006 , 'Pedro Obiang' , 29 , 'Equatorial Guinea' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Pedro Rodriguez' , 34 , 'Spain' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 2 , 0 , 'Right' , 8 , 6 , 2 ),  

( 1013 , 'Peter Crouch' , 40 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Petr Čech' , 39 , 'Czech Republic' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Phil Bardsley' , 36 , 'Scotland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 9 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Phil Jagielka' , 39 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 1 , 'Right' , 1 , 1 , 0 ),  

( 1007 , 'Phil Jones' , 29 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Philip Billing' , 25 , 'Denmark' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 7 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1001 , 'Philip Foden' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1001 , 'Philippe Sandler' , 24 , 'Netherlands' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Pierre-Emerick Aubameyang' , 32 , 'Gabon' , 'Forward' , 5 , 4 , 1 , 4 , 1 , 0 , 0 , 'Right' , 22 , 13 , 9 ),  

( 1014 , 'Pierre-Emile Højbjerg' , 26 , 'Denmark' , 'Midfielder' , 3 , 2 , 1 , 0 , 0 , 10 , 2 , 'Right' , 4 , 2 , 2 ),  

( 1009 , 'Rachid Ghezzal' , 29 , 'Algeria' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1002 , 'Rafael Euclides Soares Camacho' , 21 , 'Portugal' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Raheem Sterling' , 27 , 'England' , 'Forward' , 10 , 6 , 4 , 0 , 0 , 3 , 0 , 'Left' , 17 , 12 , 5 ),  

( 1016 , 'Rajiv van La Parra' , 30 , 'Netherlands' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Ramadan Sobhi' , 24 , 'Egypt' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Raúl Alonso Jiménez Rodríguez' , 30 , 'Mexico' , 'Forward' , 7 , 4 , 3 , 2 , 0 , 4 , 0 , 'Right' , 13 , 8 , 5 ),  

( 1020 , 'Rhys Healey' , 27 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'Ricardo Domingos Barbosa Pereira' , 28 , 'Portugal' , 'Defender' , 6 , 3 , 3 , 0 , 0 , 7 , 0 , 'Left' , 2 , 2 , 0 ),  

( 1017 , 'Richarlison de Andrade' , 24 , 'Brazil' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 6 , 1 , 'Left' , 13 , 7 , 6 ),  

( 1001 , 'Riyad Mahrez' , 30 , 'Algeria' , 'Midfielder' , 4 , 2 , 2 , 0 , 1 , 0 , 0 , 'Left' , 7 , 1 , 6 ),  

( 1005 , 'Rob Holding' , 26 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Robbie Brady' , 29 , 'Republic of Ireland' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 4 , 1 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Robert Kenedy Nunes do Nascimento' , 25 , 'Brazil' , 'Midfielder' , 1 , 1 , 0 , 0 , 1 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1006 , 'Robert Snodgrass' , 34 , 'Scotland' , 'Midfielder' , 5 , 4 , 1 , 0 , 0 , 10 , 0 , 'Left' , 2 , 1 , 1 ),  

( 1002 , 'Roberto Firmino' , 30 , 'Brazil' , 'Forward' , 6 , 3 , 3 , 1 , 0 , 0 , 0 , 'Left' , 12 , 7 , 5 ),  

( 1019 , 'Roberto Maximiliano Pereyra' , 31 , 'Argentina' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 3 , 0 , 'Left' , 6 , 5 , 1 ),  

( 1008 , 'Romain Saïss' , 31 , 'Morocco' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 7 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1007 , 'Romelu Lukaku' , 28 , 'Belgium' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Right' , 12 , 4 , 8 ),  

( 1015 , 'Rondon' , 32 , 'Venezuela' , 'Forward' , 7 , 5 , 2 , 0 , 0 , 1 , 0 , 'Right' , 11 , 6 , 5 ),  

( 1003 , 'Ross Barkley' , 28 , 'England' , 'Midfielder' , 5 , 2 , 3 , 0 , 0 , 1 , 0 , 'Left' , 3 , 1 , 2 ),  

( 1008 , 'Rúben Diogo Da Silva Neves' , 24 , 'Portugal' , 'Midfielder' , 3 , 2 , 1 , 2 , 0 , 8 , 0 , 'Left' , 4 , 3 , 1 ),  

( 1008 , 'Rúben Gonçalo Silva Nascimento Vinagre' , 22 , 'Portugal' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1003 , 'Ruben Loftus-Cheek' , 25 , 'England' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 0 , 0 , 'Left' , 6 , 3 , 3 ),  

( 1008 , 'Rui Pedro dos Santos Patrício' , 33 , 'Portugal' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1008 , 'Ryan Bennett' , 31 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 12 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1014 , 'Ryan Bertrand' , 32 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 8 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1012 , 'Ryan Fraser' , 27 , 'Scotland' , 'Midfielder' , 14 , 5 , 9 , 0 , 0 , 2 , 0 , 'Left' , 7 , 5 , 2 ),  

( 1006 , 'Ryan Fredericks' , 29 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 5 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1008 , 'Ryan Giles' , 21 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1018 , 'Ryan Guno Babel' , 35 , 'Netherlands' , 'Forward' , 3 , 3 , 0 , 0 , 0 , 3 , 0 , 'Right' , 5 , 3 , 2 ),  

( 1016 , 'Ryan Schofield' , 22 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Ryan Sessegnon' , 21 , 'England' , 'Defender' , 6 , 3 , 3 , 0 , 0 , 0 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1002 , 'Sadio Mané' , 29 , 'Senegal' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 2 , 0 , 'Left' , 22 , 18 , 4 ),  

( 1014 , 'Sam Gallagher' , 26 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1012 , 'Sam Surridge' , 23 , 'England' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Sam Vokes' , 32 , 'Wales' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1010 , 'Sam Woods' , 23 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Samir Nasri' , 34 , 'France' , 'Midfielder' , 2 , 2 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Sandro Ramirez' , 26 , 'Spain' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Scott Dann' , 34 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'Scott McTominay' , 25 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 2 , 0 , 2 ),  

( 1005 , 'Sead Kolašinac' , 28 , 'Bosnia' , 'Defender' , 5 , 3 , 2 , 0 , 0 , 5 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1017 , 'Séamus Coleman' , 33 , 'Republic of Ireland' , 'Defender' , 2 , 0 , 2 , 0 , 0 , 1 , 0 , 'Right' , 2 , 2 , 0 ),  

( 1015 , 'Sean Longstaff' , 24 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1020 , 'Sean Morrison' , 31 , 'England' , 'Defender' , 3 , 2 , 1 , 0 , 0 , 6 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1019 , 'Sebastian Prödl' , 34 , 'Austria' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1004 , 'Serge Aurier' , 29 , 'Côte  dIvoire' , 'Defender' , 2 , 0 , 2 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1001 , 'Sergio Aguero' , 33 , 'Argentina' , 'Forward' , 8 , 5 , 3 , 2 , 0 , 3 , 0 , 'Left' , 21 , 15 , 6 ),  

( 1007 , 'Sergio Germán Romero' , 34 , 'Argentina' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1018 , 'Sergio Rico' , 28 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1011 , 'Shane Duffy' , 30 , 'Republic of Ireland' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 1 , 'Right' , 5 , 2 , 3 ),  

( 1014 , 'Shane Long' , 34 , 'Republic of Ireland' , 'Forward' , 1 , 1 , 0 , 0 , 0 , 3 , 0 , 'Right' , 5 , 3 , 2 ),  

( 1009 , 'Shinji Okazaki' , 35 , 'Japan' , 'Forward' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Shkodran Mustafi' , 29 , 'Germany' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 9 , 0 , 'Left' , 2 , 0 , 2 ),  

( 1012 , 'Simon Francis' , 36 , 'England' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1002 , 'Simon Mignolet' , 33 , 'Belgium' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Sokratis Papastathopoulos' , 33 , 'Greece' , 'Defender' , 2 , 2 , 0 , 0 , 0 , 12 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1011 , 'Solomon March' , 27 , 'England' , 'Midfielder' , 5 , 1 , 4 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1020 , 'Souleymane Bamba' , 36 , 'Côte  dIvoire' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 7 , 0 , 'Left' , 4 , 2 , 2 ),  

( 1018 , 'Stefan Marius Johansen' , 31 , 'Norway' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 4 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1019 , 'Stefano Okaka' , 32 , 'Italy' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1005 , 'Stephan Lichtsteiner' , 37 , 'Switzerland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Stephen Ward' , 36 , 'Republic of Ireland' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Steve Cook' , 30 , 'England' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 3 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1016 , 'Steve Mounié' , 27 , 'Benin' , 'Forward' , 3 , 1 , 2 , 0 , 0 , 2 , 1 , 'Left' , 2 , 2 , 0 ),  

( 1014 , 'Steven Davis' , 37 , 'Northern Ireland' , 'Midfielder' , 1 , 0 , 1 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1013 , 'Steven Defour' , 33 , 'Belgium' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Stuart Armstrong' , 29 , 'Scotland' , 'Midfielder' , 2 , 1 , 1 , 0 , 0 , 2 , 0 , 'Right' , 3 , 1 , 2 ),  

( 1010 , 'Sullay Kaikai' , 26 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1015 , 'Sung-Yeung Ki' , 32 , 'South Korea' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1007 , 'Tahith Chong' , 22 , 'Netherlands' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1016 , 'Terence Kongolo' , 27 , 'Netherlands' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 4 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1017 , 'Theo Walcott' , 32 , 'England' , 'Forward' , 2 , 2 , 0 , 0 , 0 , 1 , 0 , 'Left' , 5 , 3 , 2 ),  

( 1018 , 'Tim Ream' , 34 , 'USA' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Timothy Eyoma' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Timothy Fosu-Mensah' , 24 , 'Netherlands' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Toby Alderweireld' , 32 , 'Belgium' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1018 , 'Tom Cairney' , 30 , 'Scotland' , 'Midfielder' , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1019 , 'Tom Cleverley' , 32 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1017 , 'Tom Davies' , 23 , 'England' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1013 , 'Tom Heaton' , 35 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1016 , 'Tom Smith' , 29 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 1 , 'Right' , 0 , 0 , 0 ),  

( 1002 , 'Trent Alexander-Arnold' , 23 , 'England' , 'Defender' , 12 , 8 , 4 , 0 , 0 , 3 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1019 , 'Troy Deeney' , 33 , 'England' , 'Forward' , 5 , 1 , 4 , 1 , 0 , 5 , 1 , 'Left' , 9 , 3 , 6 ),  

( 1017 , 'Tyias Browning' , 27 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1014 , 'Tyreke Johnson' , 23 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1012 , 'Tyrone Mings' , 28 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1010 , 'Vicente Guaita' , 34 , 'Spain' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'Vicente Iborra De La Fuente' , 33 , 'Spain' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1020 , 'Víctor Camarasa' , 27 , 'Spain' , 'Midfielder' , 4 , 1 , 3 , 1 , 0 , 6 , 0 , 'Left' , 5 , 4 , 1 ),  

( 1003 , 'Victor Moses' , 31 , 'Nigeria' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1007 , 'Victor Nilsson Lindelöf' , 27 , 'Sweden' , 'Defender' , 1 , 0 , 1 , 0 , 0 , 1 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1004 , 'Victor Wanyama' , 30 , 'Kenya' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 1 , 1 , 0 ),  

( 1011 , 'Viktor Gyökeres' , 23 , 'Sweden' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1004 , 'Vincent Janssen' , 27 , 'Netherlands' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1001 , 'Vincent Kompany' , 35 , 'Belgium' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 6 , 0 , 'Left' , 1 , 1 , 0 ),  

( 1002 , 'Virgil van Dijk' , 30 , 'Netherlands' , 'Defender' , 2 , 1 , 1 , 0 , 0 , 1 , 0 , 'Left' , 4 , 2 , 2 ),  

( 1010 , 'Wayne Hennessey' , 34 , 'Wales' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1009 , 'Wes Morgan' , 37 , 'Jamaica' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 5 , 2 , 'Right' , 3 , 1 , 2 ),  

( 1014 , 'Wesley Hoedt' , 27 , 'Netherlands' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1003 , 'Wilfredo Daniel Caballero' , 40 , 'Argentina' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1010 , 'Wilfried Zaha' , 29 , 'Côte  dIvoire' , 'Midfielder' , 5 , 3 , 2 , 0 , 0 , 10 , 1 , 'Left' , 10 , 1 , 9 ),  

( 1019 , 'Will Hughes' , 26 , 'England' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 5 , 0 , 'Right' , 2 , 1 , 1 ),  

( 1008 , 'Will Norris' , 28 , 'England' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 ),  

( 1003 , 'Willian' , 33 , 'Brazil' , 'Forward' , 6 , 3 , 3 , 0 , 0 , 2 , 0 , 'Right' , 3 , 2 , 1 ),  

( 1008 , 'Willy Boly' , 30 , 'France' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 1 , 'Right' , 4 , 2 , 2 ),  

( 1002 , 'Xherdan Shaqiri' , 30 , 'Switzerland' , 'Midfielder' , 3 , 0 , 3 , 0 , 0 , 2 , 0 , 'Right' , 6 , 5 , 1 ),  

( 1014 , 'Yann Valery' , 22 , 'France' , 'Defender' , 1 , 1 , 0 , 0 , 0 , 5 , 1 , 'Left' , 2 , 1 , 1 ),  

( 1017 , 'Yerry Fernando Mina González' , 27 , 'Colombia' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 3 , 0 , 'Left' , 1 , 0 , 1 ),  

( 1015 , 'Yoshinori Muto' , 29 , 'Japan' , 'Forward' , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 'Right' , 1 , 0 , 1 ),  

( 1009 , 'Youri Tielemans' , 24 , 'Belgium' , 'Midfielder' , 4 , 2 , 2 , 0 , 0 , 2 , 0 , 'Left' , 3 , 2 , 1 ),  

( 1011 , 'Yves Bissouma' , 25 , 'Mali' , 'Midfielder' , 0 , 0 , 0 , 0 , 0 , 5 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1005 , 'Zechariah Medley' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1018 , 'Zeze Steven Sessegnon' , 21 , 'England' , 'Defender' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Right' , 0 , 0 , 0 ),  

( 1006 , 'Łukasz Fabiański' , 36 , 'Poland' , 'Goalkeeper' , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 'Left' , 0 , 0 , 0 );  

  

 

 

INSERT INTO Referee (Country,Name,ExpiryDate)  

VALUES  

('Cheshire', 'Anthony Taylor', null),  

('Northumberland', 'Michael Oliver', null),  

('Lancashire', 'Paul Tierney', null),  

('South Yorkshire', 'Craig Pawson', null),  

('West Yorkshire', 'Martin Atkinson', null),  

('West Yorkshire', 'Jonathan Moss', null),  

(' Wirral', 'Mike Dean', null),  

(' Nottinghamshire', 'David Coote', null),  

('West Midlands', 'Andre Marriner', null),  

('Warwickshire', 'Stuart Attwell', null),  

('Leicestershire', 'Kevin Friend', null),  

('Andrew Madley', 'West Yorkshire', null),  

('Wiltshire', 'Simon Hooper', null),  

('South Yorkshire', 'Darren England', null),  

('Lancashire', 'Chris Kavanagh', null);  

  

INSERT INTO Match (CommitteeID,RefereeID,VenueID,TeamA,TeamB,TeamA_Score,TeamB_Score,Extra_Time,MatchDate)  

VALUES  

('250', '401', '50', '1001', '1002', '2', '3', '1', '02-03-2021'),  

('250', '402', '51', '1003', '1004', '0', '1', '2', '02-04-2021'),  

('250', '403', '52', '1005', '1006', '3', '2', '3', '02-05-2021'),  

('250', '404', '53', '1007', '1008', '5', '4', '4', '02-06-2021'),  

('250', '405', '54', '1009', '1010', '2', '1', '5', '02-07-2021'),  

('250', '406', '55', '1011', '1012', '3', '5', '6', '02-08-2021'),  

('250', '407', '56', '1002', '1013', '1', '2', '7', '02-09-2021'),  

('250', '408', '57', '1014', '1015', '2', '4', '8', '02-10-2021'),  

('250', '409', '58', '1016', '1017', '1', '4', '9', '02-11-2021'),  

('250', '410', '57', '1018', '1019', '3', '2', '0', '02-12-2021'),  

('250', '411', '56', '1020', '1001', '1', '0', '0', '02-01-2021'),  

('250', '412', '57', '1019', '1003', '0', '0', '2', '02-03-2021'),  

('250', '413', '59', '1002', '1007', '2', '2', '11', '02-02-2021'),  

('250', '401', '60', '1018', '1004', '3', '2', '12', '04-03-2021'),  

('250', '402', '61', '1017', '1008', '1', '0', '15', '04-05-2021'),  

('250', '401', '62', '1016', '1020', '2', '3', '3', '04-06-2021'),
('250', '401', '50', '1001', '1002', '2', '3', '1', '08-03-2021'),

('250', '402', '50', '1003', '1004', '0', '1', '2', '08-04-2021'),

('250', '401', '50', '1005', '1006', '3', '2', '3', '08-05-2021'),

('250', '402', '50', '1007', '1008', '5', '4', '4', '08-06-2021'); 

  

 

INSERT INTO Goal (MatchID,PlayerID,Time)  

VALUES  

('450', '4067', '2021-02-03 23:59:59'),  

('450', '4067', '2021-02-03 23:59:59'),  

('450', '4133', '2021-02-03 23:59:59'),  

('450', '4163', '2021-02-03 23:59:59'),  

('450', '4133', '2021-02-03 23:59:59'),  

('451', '4151', '2021-02-04 23:59:59'),  

('452', '4003', '2021-02-05 23:59:59'),  

('452', '4003', '2021-02-05 23:59:59'),  

('452', '4019', '2021-02-05 23:59:59'),  

('452', '4047', '2021-02-05 23:59:59'),  

('452', '4047', '2021-02-05 23:59:59'),  

('453', '4055', '2021-02-06 23:59:59'),  

('453', '4055', '2021-02-06 23:59:59'),  

('453', '4055', '2021-02-06 23:59:59'),  

('453', '4267', '2021-02-06 23:59:59'),  

('453', '4267', '2021-02-06 23:59:59'),  

('453', '4162', '2021-02-06 23:59:59'),  

('453', '4162', '2021-02-06 23:59:59'),  

('453', '4162', '2021-02-06 23:59:59'),  

('453', '4462', '2021-02-06 23:59:59'),  

('454', '4157', '2021-02-07 23:59:59'),  

('454', '4157', '2021-02-07 23:59:59'),  

('454', '4048', '2021-02-07 23:59:59'),  

('455', '4208', '2021-02-08 23:59:59'),  

('455', '4208', '2021-02-08 23:59:59'),  

('455', '4208', '2021-02-08 23:59:59'),  

('455', '4144', '2021-02-08 23:59:59'),  

('455', '4144', '2021-02-08 23:59:59'),  

('455', '4144', '2021-02-08 23:59:59'),  

('455', '4144', '2021-02-08 23:59:59'),  

('455', '4303', '2021-02-08 23:59:59'),  

('456', '4184', '2021-02-09 23:59:59'),  

('456', '4167', '2021-02-09 23:59:59'),  

('456', '4167', '2021-02-09 23:59:59'),  

('457', '4105', '2021-02-10 23:59:59'),  

('457', '4105', '2021-02-10 23:59:59'),  

('457', '4183', '2021-02-10 23:59:59'),  

('457', '4183', '2021-02-10 23:59:59'),  

('457', '4183', '2021-02-10 23:59:59'),  

('457', '4183', '2021-02-10 23:59:59'),  

('458', '4002', '2021-02-11 23:59:59'),  

('458', '4165', '2021-02-11 23:59:59'),  

('458', '4165', '2021-02-11 23:59:59'),  

('458', '4165', '2021-02-11 23:59:59'),  

('458', '4165', '2021-02-11 23:59:59'),  

('459', '4008', '2021-02-12 23:59:59'),  

('459', '4008', '2021-02-11 23:59:59'),  

('459', '4008', '2021-02-11 23:59:59'),  

('459', '4007', '2021-02-11 23:59:59'),  

('459', '4007', '2021-02-11 23:59:59'),  

('460', '4060', '2021-02-12 23:59:59'),  

('462', '4206', '2021-02-01 23:59:59'),  

('462', '4206', '2021-02-01 23:59:59'),  

('462', '4370', '2021-02-01 23:59:59'),  

('462', '4370', '2021-02-01 23:59:59'),  

('463', '4488', '2021-02-03 23:59:59'),  

('463', '4488', '2021-02-03 23:59:59'),  

('463', '4488', '2021-02-03 23:59:59'),  

('463', '4352', '2021-02-03 23:59:59'),  

('463', '4352', '2021-02-03 23:59:59'),  

('464', '4082', '2021-04-03 23:59:59'),  

('465', '4385', '2021-04-06 23:59:59'),  

('465', '4385', '2021-04-06 23:59:59'),  

('465', '4546', '2021-04-06 23:59:59'),  

('465', '4546', '2021-04-06 23:59:59'),  

('465', '4546', '2021-04-06 23:59:59');  

  

 

 

Insert into Sponsored_By (ContractSigned_Date,TeamID,SponsorerID) VALUES ('08-10-2015',1001,1),('08-11-2016',1001,2),  

('09-12-2014',1002,2),('01-10-2017',1002,3),('02-11-2019',1003,4),('03-12-2015',1003,5),('04-11-2016',1004,6),('05-10-2017',1004,7),  

('06-10-2018',1005,8),('07-10-2019',1005,9),('08-10-2013',1006,10),('09-10-2014',1006,1),('01-10-2015',1007,2),('02-10-2016',1007,3),  

('03-12-2017',1008,4),('04-11-2018',1008,5),('05-10-2019',1009,6),('06-12-2011',1009,7),('07-10-2012',1010,8),('08-11-2013',1010,9),  

('09-12-2014',1011,10),('01-10-2015',1011,1),('02-11-2016',1012,2),('03-12-2017',1012,3),('04-10-2018',1013,4),('05-11-2019',1013,5),  

('06-10-2011',1014,6),('07-10-2012',1014,7),('08-10-2013',1015,8),('09-10-2014',1015,9),('02-10-2015',1016,10),('01-10-2016',1016,1),  

('02-12-2017',1017,2),('03-10-2018',1017,3),('04-11-2019',1018,4),('05-12-2011',1018,5),('06-10-2012',1019,6),('07-11-2013',1019,7),  

('08-12-2014',1020,8),('09-10-2015',1020,9);  

 

 

  

 

INSERT INTO GoalKeeper (PlayerID,Goals_saved) 

VALUES 

    (4000, 0), 

    (4001, 0), 

    (4002, 0), 

    (4003, 0), 

    (4004, 0), 

    (4005, 0), 

    (4006, 0), 

    (4007, 0), 

    (4008, 0), 

    (4009, 0), 

    (4010, 0), 

    (4011, 0), 

    (4012, 0), 

    (4013, 0), 

    (4014, 0), 

    (4015, 0), 

    (4016, 0), 

    (4017, 35), 

    (4018, 0), 

    (4019, 0), 

    (4020, 0), 

    (4021, 0), 

    (4022, 0), 

    (4023, 110), 

    (4024, 0), 

    (4025, 0), 

    (4026, 52), 

    (4027, 0), 

    (4028, 0), 

    (4029, 0), 

    (4030, 0), 

    (4031, 0), 

    (4032, 0), 

    (4033, 68), 

    (4034, 0), 

    (4035, 0), 

    (4036, 89), 

    (4037, 0), 

    (4038, 0), 

    (4039, 0), 

    (4040, 0), 

    (4041, 0), 

    (4042, 0), 

    (4043, 0), 

    (4044, 0), 

    (4045, 0), 

    (4046, 0), 

    (4047, 0), 

    (4048, 0), 

    (4049, 0), 

    (4050, 0), 

    (4051, 0), 

    (4052, 98), 

    (4053, 0), 

    (4054, 0), 

    (4055, 0), 

    (4056, 0), 

    (4057, 0), 

    (4058, 0), 

    (4059, 12), 

    (4060, 0), 

    (4061, 0), 

    (4062, 112), 

    (4063, 0), 

    (4064, 0), 

    (4065, 0), 

    (4066, 123), 

    (4067, 0), 

    (4068, 0), 

    (4069, 0), 

    (4070, 0), 

    (4071, 0), 

    (4072, 0), 

    (4073, 123), 

    (4074, 0), 

    (4075, 102), 

    (4076, 0), 

    (4077, 0), 

    (4078, 0), 

    (4079, 0), 

    (4080, 0), 

    (4081, 0), 

    (4082, 0), 

    (4083, 0), 

    (4084, 0), 

    (4085, 98), 

    (4086, 0), 

    (4087, 23), 

    (4088, 0), 

    (4089, 0), 

    (4090, 0), 

    (4091, 0), 

    (4092, 0), 

    (4093, 0), 

    (4094, 0), 

    (4095, 0), 

    (4096, 0), 

    (4097, 0), 

    (4098, 0), 

    (4099, 0), 

    (4100, 0), 

    (4101, 0), 

    (4102, 0), 

    (4103, 0), 

    (4104, 0), 

    (4105, 0), 

    (4106, 0), 

    (4107, 0), 

    (4108, 0), 

    (4109, 0), 

    (4110, 0), 

    (4111, 0), 

    (4112, 0), 

    (4113, 0), 

    (4114, 0), 

    (4115, 0), 

    (4116, 0), 

    (4117, 0), 

    (4118, 0), 

    (4119, 0), 

    (4120, 12), 

    (4121, 0), 

    (4122, 0), 

    (4123, 0), 

    (4124, 0), 

    (4125, 0), 

    (4126, 0), 

    (4127, 0), 

    (4128, 0), 

    (4129, 32), 

    (4130, 0), 

    (4131, 0), 

    (4132, 0), 

    (4133, 0), 

    (4134, 0), 

    (4135, 0), 

    (4136, 0), 

    (4137, 0), 

    (4138, 0), 

    (4139, 0), 

    (4140, 12), 

    (4141, 0), 

    (4142, 0), 

    (4143, 0), 

    (4144, 0), 

    (4145, 98), 

    (4146, 187), 

    (4147, 0), 

    (4148, 0), 

    (4149, 0), 

    (4150, 0), 

    (4151, 0), 

    (4152, 0), 

    (4153, 0), 

    (4154, 0), 

    (4155, 0), 

    (4156, 0), 

    (4157, 0), 

    (4158, 0), 

    (4159, 0), 

    (4160, 0), 

    (4161, 0), 

    (4162, 0), 

    (4163, 0), 

    (4164, 0), 

    (4165, 0), 

    (4166, 0), 

    (4167, 0), 

    (4168, 0), 

    (4169, 43), 

    (4170, 0), 

    (4171, 0), 

    (4172, 0), 

    (4173, 0), 

    (4174, 0), 

    (4175, 0), 

    (4176, 0), 

    (4177, 0), 

    (4178, 0), 

    (4179, 0), 

    (4180, 0), 

    (4181, 0), 

    (4182, 0), 

    (4183, 0), 

    (4184, 0), 

    (4185, 10), 

    (4186, 0), 

    (4187, 0), 

    (4188, 0), 

    (4189, 0), 

    (4190, 0), 

    (4191, 0), 

    (4192, 0), 

    (4193, 0), 

    (4194, 0), 

    (4195, 0), 

    (4196, 0), 

    (4197, 10), 

    (4198, 10), 

    (4199, 0), 

    (4200, 0), 

    (4201, 0), 

    (4202, 0), 

    (4203, 0), 

    (4204, 0), 

    (4205, 0), 

    (4206, 0), 

    (4207, 0), 

    (4208, 0), 

    (4209, 0), 

    (4210, 0), 

    (4211, 0), 

    (4212, 0), 

    (4213, 0), 

    (4214, 0), 

    (4215, 0), 

    (4216, 0), 

    (4217, 0), 

    (4218, 0), 

    (4219, 0), 

    (4220, 0), 

    (4221, 0), 

    (4222, 0), 

    (4223, 0), 

    (4224, 0), 

    (4225, 0), 

    (4226, 10), 

    (4227, 43), 

    (4228, 0), 

    (4229, 0), 

    (4230, 0), 

    (4231, 0), 

    (4232, 0), 

    (4233, 0), 

    (4234, 0), 

    (4235, 0), 

    (4236, 0), 

    (4237, 0), 

    (4238, 0), 

    (4239, 0), 

    (4240, 0), 

    (4241, 0), 

    (4242, 0), 

    (4243, 0), 

    (4244, 0), 

    (4245, 0), 

    (4246, 0), 

    (4247, 0), 

    (4248, 0), 

    (4249, 0), 

    (4250, 0), 

    (4251, 0), 

    (4252, 0), 

    (4253, 0), 

    (4254, 0), 

    (4255, 0), 

    (4256, 0), 

    (4257, 11), 

    (4258, 0), 

    (4259, 0), 

    (4260, 0), 

    (4261, 0), 

    (4262, 0), 

    (4263, 0), 

    (4264, 0), 

    (4265, 0), 

    (4266, 0), 

    (4267, 0), 

    (4268, 0), 

    (4269, 0), 

    (4270, 0), 

    (4271, 9), 

    (4272, 0), 

    (4273, 123), 

    (4274, 0), 

    (4275, 0), 

    (4276, 34), 

    (4277, 0), 

    (4278, 0), 

    (4279, 0), 

    (4280, 23), 

    (4281, 0), 

    (4282, 0), 

    (4283, 111), 

    (4284, 0), 

    (4285, 0), 

    (4286, 0), 

    (4287, 0), 

    (4288, 0), 

    (4289, 0), 

    (4290, 0), 

    (4291, 0), 

    (4292, 98), 

    (4293, 0), 

    (4294, 0), 

    (4295, 0), 

    (4296, 0), 

    (4297, 0), 

    (4298, 0), 

    (4299, 0), 

    (4300, 0), 

    (4301, 0), 

    (4302, 0), 

    (4303, 0), 

    (4304, 0), 

    (4305, 0), 

    (4306, 0), 

    (4307, 12), 

    (4308, 0), 

    (4309, 0), 

    (4310, 0), 

    (4311, 0), 

    (4312, 15), 

    (4313, 0), 

    (4314, 74), 

    (4315, 0), 

    (4316, 0), 

    (4317, 0), 

    (4318, 0), 

    (4319, 0), 

    (4320, 0), 

    (4321, 111), 

    (4322, 0), 

    (4323, 0), 

    (4324, 0), 

    (4325, 0), 

    (4326, 0), 

    (4327, 0), 

    (4328, 0), 

    (4329, 0), 

    (4330, 0), 

    (4331, 0), 

    (4332, 0), 

    (4333, 0), 

    (4334, 0), 

    (4335, 0), 

    (4336, 0), 

    (4337, 0), 

    (4338, 12), 

    (4339, 0), 

    (4340, 0), 

    (4341, 0), 

    (4342, 0), 

    (4343, 0), 

    (4344, 0), 

    (4345, 0), 

    (4346, 0), 

    (4347, 0), 

    (4348, 10), 

    (4349, 0), 

    (4350, 0), 

    (4351, 0), 

    (4352, 0), 

    (4353, 0), 

    (4354, 0), 

    (4355, 0), 

    (4356, 0), 

    (4357, 0), 

    (4358, 0), 

    (4359, 0), 

    (4360, 12), 

    (4361, 0), 

    (4362, 0), 

    (4363, 0), 

    (4364, 0), 

    (4365, 0), 

    (4366, 0), 

    (4367, 0), 

    (4368, 0), 

    (4369, 97), 

    (4370, 0), 

    (4371, 0), 

    (4372, 0), 

    (4373, 12), 

    (4374, 0), 

    (4375, 0), 

    (4376, 0), 

    (4377, 76), 

    (4378, 0), 

    (4379, 0), 

    (4380, 0), 

    (4381, 0), 

    (4382, 0), 

    (4383, 0), 

    (4384, 87), 

    (4385, 0), 

    (4386, 0), 

    (4387, 0), 

    (4388, 0), 

    (4389, 0), 

    (4390, 0), 

    (4391, 0), 

    (4392, 0), 

    (4393, 0), 

    (4394, 0), 

    (4395, 0), 

    (4396, 0), 

    (4397, 0), 

    (4398, 0), 

    (4399, 0), 

    (4400, 0), 

    (4401, 0), 

    (4402, 0), 

    (4403, 0), 

    (4404, 12), 

    (4405, 0), 

    (4406, 0), 

    (4407, 0), 

    (4408, 0), 

    (4409, 0), 

    (4410, 0), 

    (4411, 0), 

    (4412, 0), 

    (4413, 0), 

    (4414, 0), 

    (4415, 0), 

    (4416, 0), 

    (4417, 0), 

    (4418, 0), 

    (4419, 0), 

    (4420, 0), 

    (4421, 0), 

    (4422, 0), 

    (4423, 0), 

    (4424, 0), 

    (4425, 0), 

    (4426, 0), 

    (4427, 98), 

    (4428, 0), 

    (4429, 0), 

    (4430, 0), 

    (4431, 0), 

    (4432, 0), 

    (4433, 0), 

    (4434, 0), 

    (4435, 0), 

    (4436, 0), 

    (4437, 0), 

    (4438, 0), 

    (4439, 0), 

    (4440, 0), 

    (4441, 0), 

    (4442, 0), 

    (4443, 0), 

    (4444, 12), 

    (4445, 0), 

    (4446, 0), 

    (4447, 0), 

    (4448, 123), 

    (4449, 0), 

    (4450, 0), 

    (4451, 0), 

    (4452, 0), 

    (4453, 0), 

    (4454, 0), 

    (4455, 0), 

    (4456, 0), 

    (4457, 0), 

    (4458, 0), 

    (4459, 0), 

    (4460, 0), 

    (4461, 0), 

    (4462, 0), 

    (4463, 0), 

    (4464, 0), 

    (4465, 0), 

    (4466, 0), 

    (4467, 0), 

    (4468, 0), 

    (4469, 0), 

    (4470, 0), 

    (4471, 0), 

    (4472, 0), 

    (4473, 0), 

    (4474, 0), 

    (4475, 0), 

    (4476, 0), 

    (4477, 0), 

    (4478, 0), 

    (4479, 0), 

    (4480, 201), 

    (4481, 0), 

    (4482, 0), 

    (4483, 0), 

    (4484, 0), 

    (4485, 0), 

    (4486, 0), 

    (4487, 12), 

    (4488, 0), 

    (4489, 0), 

    (4490, 0), 

    (4491, 0), 

    (4492, 0), 

    (4493, 0), 

    (4494, 0), 

    (4495, 0), 

    (4496, 0), 

    (4497, 0), 

    (4498, 0), 

    (4499, 0), 

    (4500, 0), 

    (4501, 0), 

    (4502, 0), 

    (4503, 0), 

    (4504, 0), 

    (4505, 23), 

    (4506, 167), 

    (4507, 0), 

    (4508, 0), 

    (4509, 0), 

    (4510, 0), 

    (4511, 0), 

    (4512, 14), 

    (4513, 0), 

    (4514, 0), 

    (4515, 0), 

    (4516, 0), 

    (4517, 0), 

    (4518, 0), 

    (4519, 0), 

    (4520, 0), 

    (4521, 0), 

    (4522, 0), 

    (4523, 0), 

    (4524, 0), 

    (4525, 0), 

    (4526, 0), 

    (4527, 0), 

    (4528, 0), 

    (4529, 0), 

    (4530, 0), 

    (4531, 0), 

    (4532, 0), 

    (4533, 0), 

    (4534, 0), 

    (4535, 0), 

    (4536, 0), 

    (4537, 76), 

    (4538, 0), 

    (4539, 0), 

    (4540, 0), 

    (4541, 0), 

    (4542, 0), 

    (4543, 0), 

    (4544, 76), 

    (4545, 0), 

    (4546, 0), 

    (4547, 0), 

    (4548, 0), 

    (4549, 0), 

    (4550, 0), 

    (4551, 0), 

    (4552, 0), 

    (4553, 0), 

    (4554, 187), 

    (4555, 0), 

    (4556, 0), 

    (4557, 12), 

    (4558, 0), 

    (4559, 0), 

    (4560, 13), 

    (4561, 0), 

    (4562, 0), 

    (4563, 0), 

    (4564, 0), 

    (4565, 0), 

    (4566, 0), 

    (4567, 0), 

    (4568, 0), 

    (4569, 0), 

    (4570, 0), 

    (4571, 98); 

 

 

 

INSERT INTO Attack (PlayerID, Rank_in_league_top_attackers, Penalty_Scored) 

VALUES 

    ( 4000 ,  290 ,  12 ), 

    ( 4001 ,  196 ,  10 ), 

    ( 4002 ,  144 ,  3 ), 

    ( 4003 ,  69 ,  6 ), 

    ( 4004 ,  0 ,  0 ), 

    ( 4005 ,  312 ,  3 ), 

    ( 4006 ,  0 ,  0 ), 

    ( 4007 ,  124 ,  5 ), 

    ( 4008 ,  38 ,  8 ), 

    ( 4009 ,  0 ,  0 ), 

    ( 4010 ,  379 ,  3 ), 

    ( 4011 ,  397 ,  3 ), 

    ( 4012 ,  227 ,  0 ), 

    ( 4013 ,  332 ,  4 ), 

    ( 4014 ,  160 ,  2 ), 

    ( 4015 ,  292 ,  6 ), 

    ( 4016 ,  396 ,  2 ), 

    ( 4017 ,  0 ,  4 ), 

    ( 4018 ,  0 ,  3 ), 

    ( 4019 ,  174 ,  6 ), 

    ( 4020 ,  0 ,  3 ), 

    ( 4021 ,  62 ,  7 ), 

    ( 4022 ,  128 ,  7 ), 

    ( 4023 ,  372 ,  7 ), 

    ( 4024 ,  0 ,  2 ), 

    ( 4025 ,  171 ,  1 ), 

    ( 4026 ,  0 ,  0 ), 

    ( 4027 ,  0 ,  0 ), 

    ( 4028 ,  21 ,  5 ), 

    ( 4029 ,  0 ,  0 ), 

    ( 4030 ,  166 ,  7 ), 

    ( 4031 ,  0 ,  0 ), 

    ( 4032 ,  307 ,  12 ), 

    ( 4033 ,  0 ,  4 ), 

    ( 4034 ,  0 ,  3 ), 

    ( 4035 ,  403 ,  6 ), 

    ( 4036 ,  417 ,  3 ), 

    ( 4037 ,  20 ,  2 ), 

    ( 4038 ,  134 ,  4 ), 

    ( 4039 ,  220 ,  3 ), 

    ( 4040 ,  25 ,  6 ), 

    ( 4041 ,  54 ,  3 ), 

    ( 4042 ,  288 ,  7 ), 

    ( 4043 ,  338 ,  7 ), 

    ( 4044 ,  117 ,  7 ), 

    ( 4045 ,  418 ,  2 ), 

    ( 4046 ,  359 ,  1 ), 

    ( 4047 ,  36 ,  5 ), 

    ( 4048 ,  102 ,  7 ), 

    ( 4049 ,  270 ,  12 ), 

    ( 4050 ,  0 ,  10 ), 

    ( 4051 ,  226 ,  5 ), 

    ( 4052 ,  376 ,  12 ), 

    ( 4053 ,  0 ,  2 ), 

    ( 4054 ,  159 ,  3 ), 

    ( 4055 ,  13 ,  6 ), 

    ( 4056 ,  0 ,  3 ), 

    ( 4057 ,  259 ,  2 ), 

    ( 4058 ,  300 ,  4 ), 

    ( 4059 ,  0 ,  3 ), 

    ( 4060 ,  232 ,  6 ), 

    ( 4061 ,  368 ,  3 ), 

    ( 4062 ,  361 ,  7 ), 

    ( 4063 ,  27 ,  7 ), 

    ( 4064 ,  212 ,  7 ), 

    ( 4065 ,  195 ,  2 ), 

    ( 4066 ,  358 ,  1 ), 

    ( 4067 ,  176 ,  5 ), 

    ( 4068 ,  44 ,  7 ), 

    ( 4069 ,  0 ,  12 ), 

    ( 4070 ,  0 ,  10 ), 

    ( 4071 ,  344 ,  4 ), 

    ( 4072 ,  353 ,  3 ), 

    ( 4073 ,  365 ,  6 ), 

    ( 4074 ,  0 ,  3 ), 

    ( 4075 ,  327 ,  7 ), 

    ( 4076 ,  380 ,  7 ), 

    ( 4077 ,  0 ,  7 ), 

    ( 4078 ,  0 ,  2 ), 

    ( 4079 ,  0 ,  1 ), 

    ( 4080 ,  311 ,  5 ), 

    ( 4081 ,  163 ,  7 ), 

    ( 4082 ,  243 ,  12 ), 

    ( 4083 ,  400 ,  10 ), 

    ( 4084 ,  85 ,  5 ), 

    ( 4085 ,  390 ,  12 ), 

    ( 4086 ,  55 ,  2 ), 

    ( 4087 ,  0 ,  3 ), 

    ( 4088 ,  0 ,  6 ), 

    ( 4089 ,  337 ,  3 ), 

    ( 4090 ,  399 ,  2 ), 

    ( 4091 ,  267 ,  4 ), 

    ( 4092 ,  277 ,  3 ), 

    ( 4093 ,  108 ,  6 ), 

    ( 4094 ,  0 ,  3 ), 

    ( 4095 ,  0 ,  7 ), 

    ( 4096 ,  17 ,  7 ), 

    ( 4097 ,  198 ,  7 ), 

    ( 4098 ,  0 ,  2 ), 

    ( 4099 ,  0 ,  1 ), 

    ( 4100 ,  0 ,  5 ), 

    ( 4101 ,  204 ,  7 ), 

    ( 4102 ,  74 ,  12 ), 

    ( 4103 ,  260 ,  3 ), 

    ( 4104 ,  0 ,  4 ), 

    ( 4105 ,  105 ,  3 ), 

    ( 4106 ,  208 ,  6 ), 

    ( 4107 ,  381 ,  3 ), 

    ( 4108 ,  323 ,  7 ), 

    ( 4109 ,  328 ,  7 ), 

    ( 4110 ,  279 ,  7 ), 

    ( 4111 ,  246 ,  2 ), 

    ( 4112 ,  50 ,  1 ), 

    ( 4113 ,  206 ,  5 ), 

    ( 4114 ,  149 ,  7 ), 

    ( 4115 ,  76 ,  12 ), 

    ( 4116 ,  0 ,  10 ), 

    ( 4117 ,  393 ,  5 ), 

    ( 4118 ,  252 ,  12 ), 

    ( 4119 ,  56 ,  2 ), 

    ( 4120 ,  0 ,  3 ), 

    ( 4121 ,  0 ,  6 ), 

    ( 4122 ,  0 ,  3 ), 

    ( 4123 ,  394 ,  2 ), 

    ( 4124 ,  0 ,  4 ), 

    ( 4125 ,  177 ,  3 ), 

    ( 4126 ,  0 ,  6 ), 

    ( 4127 ,  315 ,  3 ), 

    ( 4128 ,  247 ,  7 ), 

    ( 4129 ,  0 ,  7 ), 

    ( 4130 ,  0 ,  7 ), 

    ( 4131 ,  158 ,  2 ), 

    ( 4132 ,  343 ,  1 ), 

    ( 4133 ,  48 ,  5 ), 

    ( 4134 ,  39 ,  7 ), 

    ( 4135 ,  0 ,  0 ), 

    ( 4136 ,  151 ,  10 ), 

    ( 4137 ,  0 ,  5 ), 

    ( 4138 ,  287 ,  3 ), 

    ( 4139 ,  269 ,  4 ), 

    ( 4140 ,  0 ,  3 ), 

    ( 4141 ,  94 ,  6 ), 

    ( 4142 ,  0 ,  3 ), 

    ( 4143 ,  395 ,  7 ), 

    ( 4144 ,  68 ,  7 ), 

    ( 4145 ,  404 ,  7 ), 

    ( 4146 ,  310 ,  2 ), 

    ( 4147 ,  137 ,  1 ), 

    ( 4148 ,  186 ,  5 ), 

    ( 4149 ,  88 ,  7 ), 

    ( 4150 ,  0 ,  12 ), 

    ( 4151 ,  221 ,  10 ), 

    ( 4152 ,  241 ,  5 ), 

    ( 4153 ,  237 ,  12 ), 

    ( 4154 ,  210 ,  2 ), 

    ( 4155 ,  173 ,  3 ), 

    ( 4156 ,  82 ,  6 ), 

    ( 4157 ,  103 ,  3 ), 

    ( 4158 ,  0 ,  2 ), 

    ( 4159 ,  286 ,  4 ), 

    ( 4160 ,  0 ,  3 ), 

    ( 4161 ,  306 ,  6 ), 

    ( 4162 ,  52 ,  3 ), 

    ( 4163 ,  2 ,  7 ), 

    ( 4164 ,  72 ,  7 ), 

    ( 4165 ,  65 ,  7 ), 

    ( 4166 ,  280 ,  2 ), 

    ( 4167 ,  112 ,  1 ), 

    ( 4168 ,  18 ,  5 ), 

    ( 4169 ,  366 ,  7 ), 

    ( 4170 ,  0 ,  4 ), 

    ( 4171 ,  303 ,  3 ), 

    ( 4172 ,  0 ,  6 ), 

    ( 4173 ,  274 ,  3 ), 

    ( 4174 ,  0 ,  7 ), 

    ( 4175 ,  340 ,  7 ), 

    ( 4176 ,  107 ,  7 ), 

    ( 4177 ,  305 ,  2 ), 

    ( 4178 ,  45 ,  1 ), 

    ( 4179 ,  0 ,  5 ), 

    ( 4180 ,  253 ,  7 ), 

    ( 4181 ,  231 ,  12 ), 

    ( 4182 ,  295 ,  10 ), 

    ( 4183 ,  110 ,  5 ), 

    ( 4184 ,  229 ,  12 ), 

    ( 4185 ,  0 ,  2 ), 

    ( 4186 ,  0 ,  3 ), 

    ( 4187 ,  297 ,  6 ), 

    ( 4188 ,  70 ,  3 ), 

    ( 4189 ,  133 ,  2 ), 

    ( 4190 ,  228 ,  4 ), 

    ( 4191 ,  329 ,  3 ), 

    ( 4192 ,  278 ,  6 ), 

    ( 4193 ,  60 ,  3 ), 

    ( 4194 ,  101 ,  7 ), 

    ( 4195 ,  0 ,  7 ), 

    ( 4196 ,  240 ,  7 ), 

    ( 4197 ,  0 ,  2 ), 

    ( 4198 ,  0 ,  1 ), 

    ( 4199 ,  178 ,  5 ), 

    ( 4200 ,  6 ,  7 ), 

    ( 4201 ,  401 ,  3 ), 

    ( 4202 ,  0 ,  0 ), 

    ( 4203 ,  0 ,  1 ), 

    ( 4204 ,  0 ,  3 ), 

    ( 4205 ,  0 ,  3 ), 

    ( 4206 ,  164 ,  4 ), 

    ( 4207 ,  29 ,  4 ), 

    ( 4208 ,  24 ,  3 ), 

    ( 4209 ,  33 ,  6 ), 

    ( 4210 ,  298 ,  3 ), 

    ( 4211 ,  127 ,  7 ), 

    ( 4212 ,  313 ,  7 ), 

    ( 4213 ,  43 ,  8 ), 

    ( 4214 ,  275 ,  2 ), 

    ( 4215 ,  304 ,  1 ), 

    ( 4216 ,  5 ,  5 ), 

    ( 4217 ,  165 ,  7 ), 

    ( 4218 ,  207 ,  12 ), 

    ( 4219 ,  0 ,  10 ), 

    ( 4220 ,  175 ,  5 ), 

    ( 4221 ,  419 ,  12 ), 

    ( 4222 ,  385 ,  2 ), 

    ( 4223 ,  200 ,  3 ), 

    ( 4224 ,  53 ,  6 ), 

    ( 4225 ,  14 ,  3 ), 

    ( 4226 ,  0 ,  2 ), 

    ( 4227 ,  339 ,  4 ), 

    ( 4228 ,  0 ,  3 ), 

    ( 4229 ,  413 ,  6 ), 

    ( 4230 ,  78 ,  3 ), 

    ( 4231 ,  181 ,  7 ), 

    ( 4232 ,  219 ,  7 ), 

    ( 4233 ,  172 ,  7 ), 

    ( 4234 ,  248 ,  2 ), 

    ( 4235 ,  34 ,  1 ), 

    ( 4236 ,  249 ,  5 ), 

    ( 4237 ,  272 ,  7 ), 

    ( 4238 ,  223 ,  8 ), 

    ( 4239 ,  369 ,  3 ), 

    ( 4240 ,  301 ,  6 ), 

    ( 4241 ,  0 ,  3 ), 

    ( 4242 ,  346 ,  12 ), 

    ( 4243 ,  0 ,  13 ), 

    ( 4244 ,  83 ,  3 ), 

    ( 4245 ,  179 ,  0 ), 

    ( 4246 ,  0 ,  16 ), 

    ( 4247 ,  81 ,  3 ), 

    ( 4248 ,  170 ,  3 ), 

    ( 4249 ,  235 ,  0 ), 

    ( 4250 ,  58 ,  14 ), 

    ( 4251 ,  0 ,  17 ), 

    ( 4252 ,  9 ,  3 ), 

    ( 4253 ,  377 ,  6 ), 

    ( 4254 ,  225 ,  9 ), 

    ( 4255 ,  373 ,  3 ), 

    ( 4256 ,  302 ,  4 ), 

    ( 4257 ,  0 ,  6 ), 

    ( 4258 ,  23 ,  3 ), 

    ( 4259 ,  350 ,  8 ), 

    ( 4260 ,  0 ,  3 ), 

    ( 4261 ,  0 ,  6 ), 

    ( 4262 ,  236 ,  12 ), 

    ( 4263 ,  131 ,  3 ), 

    ( 4264 ,  202 ,  0 ), 

    ( 4265 ,  89 ,  3 ), 

    ( 4266 ,  0 ,  0 ), 

    ( 4267 ,  87 ,  0 ), 

    ( 4268 ,  258 ,  5 ), 

    ( 4269 ,  324 ,  17 ), 

    ( 4270 ,  316 ,  3 ), 

    ( 4271 ,  0 ,  6 ), 

    ( 4272 ,  407 ,  9 ), 

    ( 4273 ,  367 ,  3 ), 

    ( 4274 ,  0 ,  4 ), 

    ( 4275 ,  336 ,  7 ), 

    ( 4276 ,  0 ,  3 ), 

    ( 4277 ,  215 ,  5 ), 

    ( 4278 ,  114 ,  3 ), 

    ( 4279 ,  122 ,  6 ), 

    ( 4280 ,  0 ,  12 ), 

    ( 4281 ,  309 ,  3 ), 

    ( 4282 ,  139 ,  0 ), 

    ( 4283 ,  333 ,  3 ), 

    ( 4284 ,  330 ,  8 ), 

    ( 4285 ,  0 ,  6 ), 

    ( 4286 ,  167 ,  9 ), 

    ( 4287 ,  289 ,  3 ), 

    ( 4288 ,  257 ,  4 ), 

    ( 4289 ,  224 ,  9 ), 

    ( 4290 ,  187 ,  12 ), 

    ( 4291 ,  217 ,  3 ), 

    ( 4292 ,  409 ,  0 ), 

    ( 4293 ,  154 ,  3 ), 

    ( 4294 ,  213 ,  0 ), 

    ( 4295 ,  283 ,  11 ), 

    ( 4296 ,  153 ,  8 ), 

    ( 4297 ,  266 ,  13 ), 

    ( 4298 ,  61 ,  16 ), 

    ( 4299 ,  0 ,  14 ), 

    ( 4300 ,  0 ,  6 ), 

    ( 4301 ,  0 ,  8 ), 

    ( 4302 ,  119 ,  5 ), 

    ( 4303 ,  49 ,  7 ), 

    ( 4304 ,  0 ,  5 ), 

    ( 4305 ,  157 ,  8 ), 

    ( 4306 ,  92 ,  9 ), 

    ( 4307 ,  0 ,  0 ), 

    ( 4308 ,  205 ,  5 ), 

    ( 4309 ,  104 ,  8 ), 

    ( 4310 ,  120 ,  13 ), 

    ( 4311 ,  79 ,  16 ), 

    ( 4312 ,  0 ,  14 ), 

    ( 4313 ,  31 ,  6 ), 

    ( 4314 ,  342 ,  8 ), 

    ( 4315 ,  0 ,  5 ), 

    ( 4316 ,  0 ,  7 ), 

    ( 4317 ,  169 ,  5 ), 

    ( 4318 ,  0 ,  8 ), 

    ( 4319 ,  143 ,  9 ), 

    ( 4320 ,  142 ,  17 ), 

    ( 4321 ,  364 ,  3 ), 

    ( 4322 ,  109 ,  9 ), 

    ( 4323 ,  293 ,  3 ), 

    ( 4324 ,  317 ,  5 ), 

    ( 4325 ,  0 ,  4 ), 

    ( 4326 ,  230 ,  3 ), 

    ( 4327 ,  0 ,  6 ), 

    ( 4328 ,  0 ,  3 ), 

    ( 4329 ,  192 ,  0 ), 

    ( 4330 ,  0 ,  3 ), 

    ( 4331 ,  250 ,  4 ), 

    ( 4332 ,  357 ,  6 ), 

    ( 4333 ,  331 ,  9 ), 

    ( 4334 ,  93 ,  3 ), 

    ( 4335 ,  0 ,  4 ), 

    ( 4336 ,  146 ,  5 ), 

    ( 4337 ,  281 ,  8 ), 

    ( 4338 ,  0 ,  13 ), 

    ( 4339 ,  352 ,  16 ), 

    ( 4340 ,  410 ,  14 ), 

    ( 4341 ,  121 ,  6 ), 

    ( 4342 ,  0 ,  8 ), 

    ( 4343 ,  19 ,  5 ), 

    ( 4344 ,  0 ,  7 ), 

    ( 4345 ,  362 ,  5 ), 

    ( 4346 ,  203 ,  8 ), 

    ( 4347 ,  0 ,  9 ), 

    ( 4348 ,  0 ,  5 ), 

    ( 4349 ,  0 ,  8 ), 

    ( 4350 ,  147 ,  13 ), 

    ( 4351 ,  10 ,  16 ), 

    ( 4352 ,  30 ,  14 ), 

    ( 4353 ,  190 ,  6 ), 

    ( 4354 ,  180 ,  8 ), 

    ( 4355 ,  59 ,  5 ), 

    ( 4356 ,  0 ,  7 ), 

    ( 4357 ,  0 ,  5 ), 

    ( 4358 ,  262 ,  8 ), 

    ( 4359 ,  75 ,  9 ), 

    ( 4360 ,  0 ,  3 ), 

    ( 4361 ,  322 ,  8 ), 

    ( 4362 ,  100 ,  8 ), 

    ( 4363 ,  130 ,  13 ), 

    ( 4364 ,  156 ,  16 ), 

    ( 4365 ,  0 ,  14 ), 

    ( 4366 ,  0 ,  6 ), 

    ( 4367 ,  0 ,  8 ), 

    ( 4368 ,  191 ,  5 ), 

    ( 4369 ,  296 ,  7 ), 

    ( 4370 ,  41 ,  5 ), 

    ( 4371 ,  211 ,  8 ), 

    ( 4372 ,  96 ,  9 ), 

    ( 4373 ,  0 ,  3 ), 

    ( 4374 ,  26 ,  3 ), 

    ( 4375 ,  0 ,  4 ), 

    ( 4376 ,  341 ,  6 ), 

    ( 4377 ,  345 ,  5 ), 

    ( 4378 ,  326 ,  8 ), 

    ( 4379 ,  294 ,  13 ), 

    ( 4380 ,  0 ,  16 ), 

    ( 4381 ,  414 ,  14 ), 

    ( 4382 ,  66 ,  6 ), 

    ( 4383 ,  291 ,  8 ), 

    ( 4384 ,  398 ,  5 ), 

    ( 4385 ,  129 ,  7 ), 

    ( 4386 ,  0 ,  5 ), 

    ( 4387 ,  155 ,  8 ), 

    ( 4388 ,  216 ,  9 ), 

    ( 4389 ,  183 ,  3 ), 

    ( 4390 ,  411 ,  6 ), 

    ( 4391 ,  386 ,  9 ), 

    ( 4392 ,  0 ,  3 ), 

    ( 4393 ,  378 ,  4 ), 

    ( 4394 ,  0 ,  5 ), 

    ( 4395 ,  0 ,  8 ), 

    ( 4396 ,  0 ,  13 ), 

    ( 4397 ,  209 ,  16 ), 

    ( 4398 ,  314 ,  14 ), 

    ( 4399 ,  308 ,  6 ), 

    ( 4400 ,  73 ,  8 ), 

    ( 4401 ,  251 ,  5 ), 

    ( 4402 ,  0 ,  7 ), 

    ( 4403 ,  77 ,  5 ), 

    ( 4404 ,  0 ,  8 ), 

    ( 4405 ,  8 ,  9 ), 

    ( 4406 ,  282 ,  6 ), 

    ( 4407 ,  0 ,  9 ), 

    ( 4408 ,  348 ,  3 ), 

    ( 4409 ,  388 ,  4 ), 

    ( 4410 ,  375 ,  5 ), 

    ( 4411 ,  7 ,  8 ), 

    ( 4412 ,  408 ,  13 ), 

    ( 4413 ,  412 ,  16 ), 

    ( 4414 ,  355 ,  14 ), 

    ( 4415 ,  354 ,  6 ), 

    ( 4416 ,  141 ,  8 ), 

    ( 4417 ,  138 ,  5 ), 

    ( 4418 ,  222 ,  7 ), 

    ( 4419 ,  271 ,  5 ), 

    ( 4420 ,  150 ,  8 ), 

    ( 4421 ,  0 ,  9 ), 

    ( 4422 ,  116 ,  1 ), 

    ( 4423 ,  0 ,  3 ), 

    ( 4424 ,  392 ,  6 ), 

    ( 4425 ,  46 ,  3 ), 

    ( 4426 ,  0 ,  0 ), 

    ( 4427 ,  363 ,  3 ), 

    ( 4428 ,  239 ,  5 ), 

    ( 4429 ,  273 ,  8 ), 

    ( 4430 ,  0 ,  13 ), 

    ( 4431 ,  0 ,  16 ), 

    ( 4432 ,  284 ,  14 ), 

    ( 4433 ,  0 ,  6 ), 

    ( 4434 ,  86 ,  8 ), 

    ( 4435 ,  218 ,  5 ), 

    ( 4436 ,  244 ,  7 ), 

    ( 4437 ,  415 ,  5 ), 

    ( 4438 ,  370 ,  8 ), 

    ( 4439 ,  0 ,  9 ), 

    ( 4440 ,  126 ,  3 ), 

    ( 4441 ,  184 ,  5 ), 

    ( 4442 ,  347 ,  8 ), 

    ( 4443 ,  37 ,  13 ), 

    ( 4444 ,  0 ,  16 ), 

    ( 4445 ,  371 ,  14 ), 

    ( 4446 ,  35 ,  6 ), 

    ( 4447 ,  0 ,  8 ), 

    ( 4448 ,  384 ,  5 ), 

    ( 4449 ,  383 ,  7 ), 

    ( 4450 ,  71 ,  5 ), 

    ( 4451 ,  299 ,  8 ), 

    ( 4452 ,  185 ,  5 ), 

    ( 4453 ,  67 ,  8 ), 

    ( 4454 ,  0 ,  13 ), 

    ( 4455 ,  3 ,  16 ), 

    ( 4456 ,  136 ,  14 ), 

    ( 4457 ,  140 ,  6 ), 

    ( 4458 ,  0 ,  8 ), 

    ( 4459 ,  12 ,  5 ), 

    ( 4460 ,  335 ,  7 ), 

    ( 4461 ,  0 ,  5 ), 

    ( 4462 ,  42 ,  8 ), 

    ( 4463 ,  0 ,  9 ), 

    ( 4464 ,  214 ,  0 ), 

    ( 4465 ,  28 ,  3 ), 

    ( 4466 ,  22 ,  3 ), 

    ( 4467 ,  389 ,  6 ), 

    ( 4468 ,  268 ,  17 ), 

    ( 4469 ,  193 ,  3 ), 

    ( 4470 ,  188 ,  12 ), 

    ( 4471 ,  32 ,  3 ), 

    ( 4472 ,  97 ,  5 ), 

    ( 4473 ,  115 ,  8 ), 

    ( 4474 ,  16 ,  13 ), 

    ( 4475 ,  40 ,  16 ), 

    ( 4476 ,  84 ,  14 ), 

    ( 4477 ,  145 ,  6 ), 

    ( 4478 ,  406 ,  8 ), 

    ( 4479 ,  11 ,  5 ), 

    ( 4480 ,  405 ,  5 ), 

    ( 4481 ,  256 ,  8 ), 

    ( 4482 ,  245 ,  13 ), 

    ( 4483 ,  95 ,  16 ), 

    ( 4484 ,  189 ,  14 ), 

    ( 4485 ,  0 ,  6 ), 

    ( 4486 ,  47 ,  8 ), 

    ( 4487 ,  0 ,  5 ), 

    ( 4488 ,  182 ,  7 ), 

    ( 4489 ,  4 ,  5 ), 

    ( 4490 ,  0 ,  8 ), 

    ( 4491 ,  0 ,  9 ), 

    ( 4492 ,  64 ,  6 ), 

    ( 4493 ,  0 ,  3 ), 

    ( 4494 ,  0 ,  12 ), 

    ( 4495 ,  0 ,  5 ), 

    ( 4496 ,  276 ,  8 ), 

    ( 4497 ,  91 ,  13 ), 

    ( 4498 ,  285 ,  16 ), 

    ( 4499 ,  197 ,  14 ), 

    ( 4500 ,  135 ,  6 ), 

    ( 4501 ,  255 ,  8 ), 

    ( 4502 ,  0 ,  5 ), 

    ( 4503 ,  351 ,  7 ), 

    ( 4504 ,  1 ,  5 ), 

    ( 4505 ,  0 ,  5 ), 

    ( 4506 ,  320 ,  8 ), 

    ( 4507 ,  123 ,  13 ), 

    ( 4508 ,  51 ,  16 ), 

    ( 4509 ,  0 ,  14 ), 

    ( 4510 ,  201 ,  6 ), 

    ( 4511 ,  360 ,  8 ), 

    ( 4512 ,  0 ,  5 ), 

    ( 4513 ,  234 ,  7 ), 

    ( 4514 ,  242 ,  5 ), 

    ( 4515 ,  118 ,  8 ), 

    ( 4516 ,  318 ,  9 ), 

    ( 4517 ,  0 ,  6 ), 

    ( 4518 ,  387 ,  9 ), 

    ( 4519 ,  0 ,  3 ), 

    ( 4520 ,  254 ,  4 ), 

    ( 4521 ,  168 ,  5 ), 

    ( 4522 ,  0 ,  8 ), 

    ( 4523 ,  264 ,  13 ), 

    ( 4524 ,  98 ,  16 ), 

    ( 4525 ,  0 ,  14 ), 

    ( 4526 ,  349 ,  6 ), 

    ( 4527 ,  0 ,  8 ), 

    ( 4528 ,  261 ,  5 ), 

    ( 4529 ,  90 ,  7 ), 

    ( 4530 ,  265 ,  5 ), 

    ( 4531 ,  0 ,  8 ), 

    ( 4532 ,  319 ,  9 ), 

    ( 4533 ,  356 ,  5 ), 

    ( 4534 ,  238 ,  8 ), 

    ( 4535 ,  99 ,  13 ), 

    ( 4536 ,  416 ,  16 ), 

    ( 4537 ,  382 ,  14 ), 

    ( 4538 ,  334 ,  6 ), 

    ( 4539 ,  233 ,  8 ), 

    ( 4540 ,  57 ,  5 ), 

    ( 4541 ,  0 ,  7 ), 

    ( 4542 ,  0 ,  5 ), 

    ( 4543 ,  0 ,  8 ), 

    ( 4544 ,  325 ,  9 ), 

    ( 4545 ,  0 ,  0 ), 

    ( 4546 ,  111 ,  3 ), 

    ( 4547 ,  0 ,  0 ), 

    ( 4548 ,  263 ,  5 ), 

    ( 4549 ,  106 ,  8 ), 

    ( 4550 ,  0 ,  13 ), 

    ( 4551 ,  0 ,  16 ), 

    ( 4552 ,  194 ,  14 ), 

    ( 4553 ,  152 ,  6 ), 

    ( 4554 ,  321 ,  8 ), 

    ( 4555 ,  125 ,  5 ), 

    ( 4556 ,  374 ,  5 ), 

    ( 4557 ,  0 ,  8 ), 

    ( 4558 ,  63 ,  13 ), 

    ( 4559 ,  199 ,  16 ), 

    ( 4560 ,  0 ,  14 ), 

    ( 4561 ,  132 ,  6 ), 

    ( 4562 ,  148 ,  8 ), 

    ( 4563 ,  15 ,  5 ), 

    ( 4564 ,  162 ,  7 ), 

    ( 4565 ,  161 ,  5 ), 

    ( 4566 ,  113 ,  8 ), 

    ( 4567 ,  80 ,  9 ), 

    ( 4568 ,  402 ,  0 ), 

    ( 4569 ,  0 ,  3 ), 

    ( 4570 ,  0 ,  0 ), 

    ( 4571 ,  391 ,  17 ); 

 

 

 

 

 

  
 

 
 

INSERT INTO MidFielder (PlayerID,Rank_in_league_top_Midfielders)  

VALUES  

(4000, 191),  

 
 

(4001, 187),  

 
 

(4002, 233),  

 
 

(4003, 8),  

 
 

(4004, 0),  

 
 

(4005, 160),  

 
 

(4006, 0),  

 
 

(4007, 80),  

 
 

(4008, 412),  

 
 

(4009, 0),  

 
 

(4010, 344),  

 
 

(4011, 155),  

 
 

(4012, 228),  

 
 

(4013, 359),  

 
 

(4014, 152),  

 
 

(4015, 20),  

 
 

(4016, 414),  

 
 

(4017, 0),  

 
 

(4018, 0),  

 
 

(4019, 167),  

 
 

(4020, 0),  

 
 

(4021, 176),  

 
 

(4022, 31),  

 
 

(4023, 365),  

 
 

(4024, 0),  

 
 

(4025, 373),  

 
 

(4026, 0),  

 
 

(4027, 0),  

 
 

(4028, 25),  

 
 

(4029, 0),  

 
 

(4030, 17),  

 
 

(4031, 0),  

 
 

(4032, 255),  

 
 

(4033, 0),  

 
 

(4034, 0),  

 
 

(4035, 270),  

 
 

(4036, 387),  

 
 

(4037, 338),  

 
 

(4038, 68),  

 
 

(4039, 213),  

 
 

(4040, 109),  

 
 

(4041, 417),  

 
 

(4042, 285),  

 
 

(4043, 346),  

 
 

(4044, 93),  

 
 

(4045, 19),  

 
 

(4046, 379),  

 
 

(4047, 361),  

 
 

(4048, 127),  

 
 

(4049, 326),  

 
 

(4050, 0),  

 
 

(4051, 207),  

 
 

(4052, 339),  

 
 

(4053, 0),  

 
 

(4054, 27),  

 
 

(4055, 141),  

 
 

(4056, 0),  

 
 

(4057, 374),  

 
 

(4058, 256),  

 
 

(4059, 0),  

 
 

(4060, 234),  

 
 

(4061, 203),  

 
 

(4062, 394),  

 
 

(4063, 172),  

 
 

(4064, 55),  

 
 

(4065, 181),  

 
 

(4066, 273),  

 
 

(4067, 158),  

 
 

(4068, 197),  

 
 

(4069, 0),  

 
 

(4070, 0),  

 
 

(4071, 139),  

 
 

(4072, 274),  

 
 

(4073, 353),  

 
 

(4074, 0),  

 
 

(4075, 348),  

 
 

(4076, 211),  

 
 

(4077, 0),  

 
 

(4078, 0),  

 
 

(4079, 0),  

 
 

(4080, 3),  

 
 

(4081, 146),  

 
 

(4082, 117),  

 
 

(4083, 200),  

 
 

(4084, 58),  

 
 

(4085, 413),  

 
 

(4086, 115),  

 
 

(4087, 0),  

 
 

(4088, 0),  

 
 

(4089, 242),  

 
 

(4090, 175),  

 
 

(4091, 330),  

 
 

(4092, 54),  

 
 

(4093, 202),  

 
 

(4094, 0),  

 
 

(4095, 0),  

 
 

(4096, 16),  

 
 

(4097, 399),  

 
 

(4098, 0),  

 
 

(4099, 0),  

 
 

(4100, 0),  

 
 

(4101, 124),  

 
 

(4102, 37),  

 
 

(4103, 116),  

 
 

(4104, 0),  

 
 

(4105, 73),  

 
 

(4106, 254),  

 
 

(4107, 239),  

 
 

(4108, 161),  

 
 

(4109, 163),  

 
 

(4110, 133),  

 
 

(4111, 294),  

 
 

(4112, 188),  

 
 

(4113, 271),  

 
 

(4114, 142),  

 
 

(4115, 10),  

 
 

(4116, 0),  

 
 

(4117, 402),  

 
 

(4118, 345),  

 
 

(4119, 315),  

 
 

(4120, 0),  

 
 

(4121, 0),  

 
 

(4122, 0),  

 
 

(4123, 415),  

 
 

(4124, 0),  

 
 

(4125, 400),  

 
 

(4126, 0),  

 
 

(4127, 205),  

 
 

(4128, 224),  

 
 

(4129, 0),  

 
 

(4130, 0),  

 
 

(4131, 206),  

 
 

(4132, 313),  

 
 

(4133, 79),  

 
 

(4134, 87),  

 
 

(4135, 0),  

 
 

(4136, 318),  

 
 

(4137, 0),  

 
 

(4138, 95),  

 
 

(4139, 333),  

 
 

(4140, 0),  

 
 

(4141, 382),  

 
 

(4142, 0),  

 
 

(4143, 121),  

 
 

(4144, 66),  

 
 

(4145, 327),  

 
 

(4146, 419),  

 
 

(4147, 220),  

 
 

(4148, 198),  

 
 

(4149, 22),  

 
 

(4150, 0),  

 
 

(4151, 208),  

 
 

(4152, 226),  

 
 

(4153, 177),  

 
 

(4154, 362),  

 
 

(4155, 324),  

 
 

(4156, 97),  

 
 

(4157, 212),  

 
 

(4158, 0),  

 
 

(4159, 244),  

 
 

(4160, 0),  

 
 

(4161, 261),  

 
 

(4162, 71),  

 
 

(4163, 42),  

 
 

(4164, 316),  

 
 

(4165, 145),  

 
 

(4166, 38),  

 
 

(4167, 29),  

 
 

(4168, 5),  

 
 

(4169, 240),  

 
 

(4170, 0),  

 
 

(4171, 259),  

 
 

(4172, 0),  

 
 

(4173, 296),  

 
 

(4174, 0),  

 
 

(4175, 310),  

 
 

(4176, 278),  

 
 

(4177, 232),  

 
 

(4178, 69),  

 
 

(4179, 0),  

 
 

(4180, 153),  

 
 

(4181, 356),  

 
 

(4182, 123),  

 
 

(4183, 230),  

 
 

(4184, 166),  

 
 

(4185, 0),  

 
 

(4186, 0),  

 
 

(4187, 194),  

 
 

(4188, 130),  

 
 

(4189, 2),  

 
 

(4190, 132),  

 
 

(4191, 376),  

 
 

(4192, 301),  

 
 

(4193, 289),  

 
 

(4194, 268),  

 
 

(4195, 0),  

 
 

(4196, 216),  

 
 

(4197, 0),  

 
 

(4198, 0),  

 
 

(4199, 156),  

 
 

(4200, 33),  

 
 

(4201, 336),  

 
 

(4202, 0),  

 
 

(4203, 0),  

 
 

(4204, 0),  

 
 

(4205, 0),  

 
 

(4206, 416),  

 
 

(4207, 59),  

 
 

(4208, 227),  

 
 

(4209, 306),  

 
 

(4210, 89),  

 
 

(4211, 183),  

 
 

(4212, 381),  

 
 

(4213, 86),  

 
 

(4214, 297),  

 
 

(4215, 221),  

 
 

(4216, 94),  

 
 

(4217, 299),  

 
 

(4218, 335),  

 
 

(4219, 0),  

 
 

(4220, 78),  

 
 

(4221, 41),  

 
 

(4222, 26),  

 
 

(4223, 113),  

 
 

(4224, 56),  

 
 

(4225, 34),  

 
 

(4226, 0),  

 
 

(4227, 284),  

 
 

(4228, 0),  

 
 

(4229, 193),  

 
 

(4230, 120),  

 
 

(4231, 154),  

 
 

(4232, 67),  

 
 

(4233, 165),  

 
 

(4234, 364),  

 
 

(4235, 119),  

 
 

(4236, 204),  

 
 

(4237, 314),  

 
 

(4238, 369),  

 
 

(4239, 48),  

 
 

(4240, 21),  

 
 

(4241, 0),  

 
 

(4242, 245),  

 
 

(4243, 0),  

 
 

(4244, 60),  

 
 

(4245, 74),  

 
 

(4246, 0),  

 
 

(4247, 65),  

 
 

(4248, 238),  

 
 

(4249, 215),  

 
 

(4250, 347),  

 
 

(4251, 0),  

 
 

(4252, 118),  

 
 

(4253, 225),  

 
 

(4254, 282),  

 
 

(4255, 367),  

 
 

(4256, 258),  

 
 

(4257, 0),  

 
 

(4258, 186),  

 
 

(4259, 40),  

 
 

(4260, 0),  

 
 

(4261, 0),  

 
 

(4262, 171),  

 
 

(4263, 349),  

 
 

(4264, 288),  

 
 

(4265, 209),  

 
 

(4266, 0),  

 
 

(4267, 135),  

 
 

(4268, 44),  

 
 

(4269, 241),  

 
 

(4270, 218),  

 
 

(4271, 0),  

 
 

(4272, 398),  

 
 

(4273, 341),  

 
 

(4274, 0),  

 
 

(4275, 383),  

 
 

(4276, 0),  

 
 

(4277, 286),  

 
 

(4278, 358),  

 
 

(4279, 18),  

 
 

(4280, 0),  

 
 

(4281, 418),  

 
 

(4282, 291),  

 
 

(4283, 247),  

 
 

(4284, 231),  

 
 

(4285, 0),  

 
 

(4286, 149),  

 
 

(4287, 143),  

 
 

(4288, 237),  

 
 

(4289, 319),  

 
 

(4290, 96),  

 
 

(4291, 102),  

 
 

(4292, 260),  

 
 

(4293, 134),  

 
 

(4294, 375),  

 
 

(4295, 77),  

 
 

(4296, 49),  

 
 

(4297, 136),  

 
 

(4298, 265),  

 
 

(4299, 0),  

 
 

(4300, 0),  

 
 

(4301, 0),  

 
 

(4302, 147),  

 
 

(4303, 157),  

 
 

(4304, 0),  

 
 

(4305, 334),  

 
 

(4306, 103),  

 
 

(4307, 0),  

 
 

(4308, 325),  

 
 

(4309, 35),  

 
 

(4310, 281),  

 
 

(4311, 262),  

 
 

(4312, 0),  

 
 

(4313, 308),  

 
 

(4314, 302),  

 
 

(4315, 0),  

 
 

(4316, 0),  

 
 

(4317, 24),  

 
 

(4318, 0),  

 
 

(4319, 47),  

 
 

(4320, 128),  

 
 

(4321, 363),  

 
 

(4322, 75),  

 
 

(4323, 72),  

 
 

(4324, 410),  

 
 

(4325, 0),  

 
 

(4326, 122),  

 
 

(4327, 0),  

 
 

(4328, 0),  

 
 

(4329, 185),  

 
 

(4330, 0),  

 
 

(4331, 248),  

 
 

(4332, 1),  

 
 

(4333, 169),  

 
 

(4334, 295),  

 
 

(4335, 0),  

 
 

(4336, 331),  

 
 

(4337, 309),  

 
 

(4338, 0),  

 
 

(4339, 391),  

 
 

(4340, 287),  

 
 

(4341, 292),  

 
 

(4342, 0),  

 
 

(4343, 4),  

 
 

(4344, 0),  

 
 

(4345, 393),  

 
 

(4346, 252),  

 
 

(4347, 0),  

 
 

(4348, 0),  

 
 

(4349, 0),  

 
 

(4350, 125),  

 
 

(4351, 276),  

 
 

(4352, 279),  

 
 

(4353, 174),  

 
 

(4354, 11),  

 
 

(4355, 210),  

 
 

(4356, 0),  

 
 

(4357, 0),  

 
 

(4358, 105),  

 
 

(4359, 395),  

 
 

(4360, 0),  

 
 

(4361, 403),  

 
 

(4362, 357),  

 
 

(4363, 111),  

 
 

(4364, 140),  

 
 

(4365, 0),  

 
 

(4366, 0),  

 
 

(4367, 0),  

 
 

(4368, 112),  

 
 

(4369, 283),  

 
 

(4370, 52),  

 
 

(4371, 195),  

 
 

(4372, 70),  

 
 

(4373, 0),  

 
 

(4374, 76),  

 
 

(4375, 0),  

 
 

(4376, 129),  

 
 

(4377, 317),  

 
 

(4378, 350),  

 
 

(4379, 229),  

 
 

(4380, 0),  

 
 

(4381, 390),  

 
 

(4382, 23),  

 
 

(4383, 150),  

 
 

(4384, 389),  

 
 

(4385, 235),  

 
 

(4386, 0),  

 
 

(4387, 100),  

 
 

(4388, 46),  

 
 

(4389, 51),  

 
 

(4390, 280),  

 
 

(4391, 405),  

 
 

(4392, 0),  

 
 

(4393, 342),  

 
 

(4394, 0),  

 
 

(4395, 0),  

 
 

(4396, 0),  

 
 

(4397, 110),  

 
 

(4398, 219),  

 
 

(4399, 192),  

 
 

(4400, 151),  

 
 

(4401, 196),  

 
 

(4402, 0),  

 
 

(4403, 85),  

 
 

(4404, 0),  

 
 

(4405, 307),  

 
 

(4406, 311),  

 
 

(4407, 0),  

 
 

(4408, 267),  

 
 

(4409, 409),  

 
 

(4410, 368),  

 
 

(4411, 57),  

 
 

(4412, 107),  

 
 

(4413, 138),  

 
 

(4414, 277),  

 
 

(4415, 131),  

 
 

(4416, 126),  

 
 

(4417, 190),  

 
 

(4418, 98),  

 
 

(4419, 397),  

 
 

(4420, 337),  

 
 

(4421, 0),  

 
 

(4422, 137),  

 
 

(4423, 0),  

 
 

(4424, 180),  

 
 

(4425, 159),  

 
 

(4426, 0),  

 
 

(4427, 392),  

 
 

(4428, 257),  

 
 

(4429, 385),  

 
 

(4430, 0),  

 
 

(4431, 0),  

 
 

(4432, 50),  

 
 

(4433, 0),  

 
 

(4434, 7),  

 
 

(4435, 332),  

 
 

(4436, 371),  

 
 

(4437, 388),  

 
 

(4438, 223),  

 
 

(4439, 0),  

 
 

(4440, 104),  

 
 

(4441, 199),  

 
 

(4442, 269),  

 
 

(4443, 30),  

 
 

(4444, 0),  

 
 

(4445, 168),  

 
 

(4446, 144),  

 
 

(4447, 0),  

 
 

(4448, 377),  

 
 

(4449, 355),  

 
 

(4450, 272),  

 
 

(4451, 189),  

 
 

(4452, 372),  

 
 

(4453, 386),  

 
 

(4454, 0),  

 
 

(4455, 88),  

 
 

(4456, 148),  

 
 

(4457, 322),  

 
 

(4458, 0),  

 
 

(4459, 14),  

 
 

(4460, 396),  

 
 

(4461, 0),  

 
 

(4462, 63),  

 
 

(4463, 0),  

 
 

(4464, 84),  

 
 

(4465, 250),  

 
 

(4466, 32),  

 
 

(4467, 411),  

 
 

(4468, 108),  

 
 

(4469, 184),  

 
 

(4470, 64),  

 
 

(4471, 62),  

 
 

(4472, 251),  

 
 

(4473, 264),  

 
 

(4474, 305),  

 
 

(4475, 43),  

 
 

(4476, 12),  

 
 

(4477, 162),  

 
 

(4478, 323),  

 
 

(4479, 83),  

 
 

(4480, 328),  

 
 

(4481, 304),  

 
 

(4482, 366),  

 
 

(4483, 9),  

 
 

(4484, 340),  

 
 

(4485, 0),  

 
 

(4486, 61),  

 
 

(4487, 0),  

 
 

(4488, 53),  

 
 

(4489, 249),  

 
 

(4490, 0),  

 
 

(4491, 0),  

 
 

(4492, 351),  

 
 

(4493, 0),  

 
 

(4494, 0),  

 
 

(4495, 0),  

 
 

(4496, 101),  

 
 

(4497, 303),  

 
 

(4498, 45),  

 
 

(4499, 178),  

 
 

(4500, 263),  

 
 

(4501, 164),  

 
 

(4502, 0),  

 
 

(4503, 15),  

 
 

(4504, 28),  

 
 

(4505, 0),  

 
 

(4506, 406),  

 
 

(4507, 253),  

 
 

(4508, 182),  

 
 

(4509, 0),  

 
 

(4510, 378),  

 
 

(4511, 99),  

 
 

(4512, 0),  

 
 

(4513, 173),  

 
 

(4514, 82),  

 
 

(4515, 222),  

 
 

(4516, 401),  

 
 

(4517, 0),  

 
 

(4518, 407),  

 
 

(4519, 0),  

 
 

(4520, 243),  

 
 

(4521, 90),  

 
 

(4522, 0),  

 
 

(4523, 321),  

 
 

(4524, 114),  

 
 

(4525, 0),  

 
 

(4526, 179),  

 
 

(4527, 0),  

 
 

(4528, 236),  

 
 

(4529, 170),  

 
 

(4530, 320),  

 
 

(4531, 0),  

 
 

(4532, 408),  

 
 

(4533, 275),  

 
 

(4534, 217),  

 
 

(4535, 298),  

 
 

(4536, 380),  

 
 

(4537, 354),  

 
 

(4538, 360),  

 
 

(4539, 6),  

 
 

(4540, 81),  

 
 

(4541, 0),  

 
 

(4542, 0),  

 
 

(4543, 0),  

 
 

(4544, 352),  

 
 

(4545, 0),  

 
 

(4546, 106),  

 
 

(4547, 0),  

 
 

(4548, 246),  

 
 

(4549, 266),  

 
 

(4550, 0),  

 
 

(4551, 0),  

 
 

(4552, 384),  

 
 

(4553, 201),  

 
 

(4554, 404),  

 
 

(4555, 300),  

 
 

(4556, 370),  

 
 

(4557, 0),  

 
 

(4558, 92),  

 
 

(4559, 91),  

 
 

(4560, 0),  

 
 

(4561, 36),  

 
 

(4562, 312),  

 
 

(4563, 39),  

 
 

(4564, 214),  

 
 

(4565, 329),  

 
 

(4566, 290),  

 
 

(4567, 13),  

 
 

(4568, 293),  

 
 

(4569, 0),  

 
 

(4570, 0),  

 
 

(4571, 343);  

 

 

 

 

 
 

INSERT INTO Defender (PlayerID,Rank_in_league_top_defenders)  

 
 

VALUES  

 
 

(4000, 80),  

 
 

(4001, 0),  

 
 

(4002, 0),  

 
 

(4003, 0),  

 
 

(4004, 0),  

 
 

(4005, 0),  

 
 

(4006, 0),  

 
 

(4007, 0),  

 
 

(4008, 0),  

 
 

(4009, 0),  

 
 

(4010, 0),  

 
 

(4011, 144),  

 
 

(4012, 85),  

 
 

(4013, 0),  

 
 

(4014, 0),  

 
 

(4015, 0),  

 
 

(4016, 94),  

 
 

(4017, 0),  

 
 

(4018, 0),  

 
 

(4019, 0),  

 
 

(4020, 0),  

 
 

(4021, 0),  

 
 

(4022, 0),  

 
 

(4023, 114),  

 
 

(4024, 0),  

 
 

(4025, 0),  

 
 

(4026, 0),  

 
 

(4027, 0),  

 
 

(4028, 0),  

 
 

(4029, 0),  

 
 

(4030, 0),  

 
 

(4031, 0),  

 
 

(4032, 161),  

 
 

(4033, 0),  

 
 

(4034, 0),  

 
 

(4035, 0),  

 
 

(4036, 3),  

 
 

(4037, 0),  

 
 

(4038, 0),  

 
 

(4039, 0),  

 
 

(4040, 0),  

 
 

(4041, 0),  

 
 

(4042, 0),  

 
 

(4043, 35),  

 
 

(4044, 0),  

 
 

(4045, 2),  

 
 

(4046, 0),  

 
 

(4047, 0),  

 
 

(4048, 0),  

 
 

(4049, 0),  

 
 

(4050, 0),  

 
 

(4051, 124),  

 
 

(4052, 104),  

 
 

(4053, 0),  

 
 

(4054, 0),  

 
 

(4055, 0),  

 
 

(4056, 0),  

 
 

(4057, 38),  

 
 

(4058, 29),  

 
 

(4059, 0),  

 
 

(4060, 0),  

 
 

(4061, 89),  

 
 

(4062, 100),  

 
 

(4063, 0),  

 
 

(4064, 0),  

 
 

(4065, 0),  

 
 

(4066, 154),  

 
 

(4067, 14),  

 
 

(4068, 0),  

 
 

(4069, 0),  

 
 

(4070, 0),  

 
 

(4071, 44),  

 
 

(4072, 60),  

 
 

(4073, 116),  

 
 

(4074, 0),  

 
 

(4075, 175),  

 
 

(4076, 118),  

 
 

(4077, 0),  

 
 

(4078, 0),  

 
 

(4079, 0),  

 
 

(4080, 12),  

 
 

(4081, 0),  

 
 

(4082, 0),  

 
 

(4083, 107),  

 
 

(4084, 0),  

 
 

(4085, 76),  

 
 

(4086, 0),  

 
 

(4087, 0),  

 
 

(4088, 0),  

 
 

(4089, 126),  

 
 

(4090, 92),  

 
 

(4091, 16),  

 
 

(4092, 0),  

 
 

(4093, 137),  

 
 

(4094, 0),  

 
 

(4095, 0),  

 
 

(4096, 0),  

 
 

(4097, 143),  

 
 

(4098, 0),  

 
 

(4099, 0),  

 
 

(4100, 0),  

 
 

(4101, 127),  

 
 

(4102, 0),  

 
 

(4103, 33),  

 
 

(4104, 0),  

 
 

(4105, 0),  

 
 

(4106, 152),  

 
 

(4107, 111),  

 
 

(4108, 0),  

 
 

(4109, 169),  

 
 

(4110, 142),  

 
 

(4111, 106),  

 
 

(4112, 0),  

 
 

(4113, 0),  

 
 

(4114, 0),  

 
 

(4115, 0),  

 
 

(4116, 0),  

 
 

(4117, 101),  

 
 

(4118, 157),  

 
 

(4119, 113),  

 
 

(4120, 0),  

 
 

(4121, 0),  

 
 

(4122, 0),  

 
 

(4123, 0),  

 
 

(4124, 0),  

 
 

(4125, 119),  

 
 

(4126, 0),  

 
 

(4127, 155),  

 
 

(4128, 0),  

 
 

(4129, 0),  

 
 

(4130, 0),  

 
 

(4131, 0),  

 
 

(4132, 0),  

 
 

(4133, 0),  

 
 

(4134, 0),  

 
 

(4135, 0),  

 
 

(4136, 18),  

 
 

(4137, 0),  

 
 

(4138, 11),  

 
 

(4139, 73),  

 
 

(4140, 0),  

 
 

(4141, 0),  

 
 

(4142, 0),  

 
 

(4143, 84),  

 
 

(4144, 0),  

 
 

(4145, 79),  

 
 

(4146, 91),  

 
 

(4147, 0),  

 
 

(4148, 27),  

 
 

(4149, 0),  

 
 

(4150, 0),  

 
 

(4151, 26),  

 
 

(4152, 0),  

 
 

(4153, 93),  

 
 

(4154, 0),  

 
 

(4155, 15),  

 
 

(4156, 0),  

 
 

(4157, 0),  

 
 

(4158, 0),  

 
 

(4159, 166),  

 
 

(4160, 0),  

 
 

(4161, 172),  

 
 

(4162, 0),  

 
 

(4163, 0),  

 
 

(4164, 0),  

 
 

(4165, 0),  

 
 

(4166, 0),  

 
 

(4167, 0),  

 
 

(4168, 0),  

 
 

(4169, 13),  

 
 

(4170, 0),  

 
 

(4171, 0),  

 
 

(4172, 0),  

 
 

(4173, 96),  

 
 

(4174, 0),  

 
 

(4175, 141),  

 
 

(4176, 0),  

 
 

(4177, 156),  

 
 

(4178, 0),  

 
 

(4179, 0),  

 
 

(4180, 0),  

 
 

(4181, 66),  

 
 

(4182, 0),  

 
 

(4183, 23),  

 
 

(4184, 0),  

 
 

(4185, 0),  

 
 

(4186, 0),  

 
 

(4187, 90),  

 
 

(4188, 0),  

 
 

(4189, 0),  

 
 

(4190, 0),  

 
 

(4191, 135),  

 
 

(4192, 36),  

 
 

(4193, 0),  

 
 

(4194, 0),  

 
 

(4195, 0),  

 
 

(4196, 0),  

 
 

(4197, 0),  

 
 

(4198, 0),  

 
 

(4199, 0),  

 
 

(4200, 0),  

 
 

(4201, 132),  

 
 

(4202, 0),  

 
 

(4203, 0),  

 
 

(4204, 0),  

 
 

(4205, 0),  

 
 

(4206, 0),  

 
 

(4207, 0),  

 
 

(4208, 0),  

 
 

(4209, 0),  

 
 

(4210, 0),  

 
 

(4211, 0),  

 
 

(4212, 170),  

 
 

(4213, 0),  

 
 

(4214, 0),  

 
 

(4215, 0),  

 
 

(4216, 0),  

 
 

(4217, 78),  

 
 

(4218, 0),  

 
 

(4219, 0),  

 
 

(4220, 0),  

 
 

(4221, 0),  

 
 

(4222, 61),  

 
 

(4223, 0),  

 
 

(4224, 0),  

 
 

(4225, 0),  

 
 

(4226, 0),  

 
 

(4227, 21),  

 
 

(4228, 0),  

 
 

(4229, 0),  

 
 

(4230, 0),  

 
 

(4231, 0),  

 
 

(4232, 0),  

 
 

(4233, 0),  

 
 

(4234, 55),  

 
 

(4235, 0),  

 
 

(4236, 0),  

 
 

(4237, 163),  

 
 

(4238, 130),  

 
 

(4239, 0),  

 
 

(4240, 0),  

 
 

(4241, 0),  

 
 

(4242, 41),  

 
 

(4243, 0),  

 
 

(4244, 0),  

 
 

(4245, 0),  

 
 

(4246, 0),  

 
 

(4247, 0),  

 
 

(4248, 121),  

 
 

(4249, 63),  

 
 

(4250, 0),  

 
 

(4251, 0),  

 
 

(4252, 0),  

 
 

(4253, 98),  

 
 

(4254, 31),  

 
 

(4255, 65),  

 
 

(4256, 0),  

 
 

(4257, 0),  

 
 

(4258, 0),  

 
 

(4259, 30),  

 
 

(4260, 0),  

 
 

(4261, 0),  

 
 

(4262, 0),  

 
 

(4263, 0),  

 
 

(4264, 0),  

 
 

(4265, 86),  

 
 

(4266, 0),  

 
 

(4267, 0),  

 
 

(4268, 0),  

 
 

(4269, 112),  

 
 

(4270, 158),  

 
 

(4271, 0),  

 
 

(4272, 1),  

 
 

(4273, 149),  

 
 

(4274, 0),  

 
 

(4275, 0),  

 
 

(4276, 0),  

 
 

(4277, 8),  

 
 

(4278, 159),  

 
 

(4279, 0),  

 
 

(4280, 0),  

 
 

(4281, 17),  

 
 

(4282, 171),  

 
 

(4283, 139),  

 
 

(4284, 0),  

 
 

(4285, 0),  

 
 

(4286, 0),  

 
 

(4287, 129),  

 
 

(4288, 59),  

 
 

(4289, 32),  

 
 

(4290, 0),  

 
 

(4291, 0),  

 
 

(4292, 57),  

 
 

(4293, 0),  

 
 

(4294, 0),  

 
 

(4295, 131),  

 
 

(4296, 105),  

 
 

(4297, 0),  

 
 

(4298, 0),  

 
 

(4299, 0),  

 
 

(4300, 0),  

 
 

(4301, 0),  

 
 

(4302, 0),  

 
 

(4303, 0),  

 
 

(4304, 0),  

 
 

(4305, 28),  

 
 

(4306, 0),  

 
 

(4307, 0),  

 
 

(4308, 0),  

 
 

(4309, 0),  

 
 

(4310, 0),  

 
 

(4311, 0),  

 
 

(4312, 0),  

 
 

(4313, 0),  

 
 

(4314, 50),  

 
 

(4315, 0),  

 
 

(4316, 0),  

 
 

(4317, 0),  

 
 

(4318, 0),  

 
 

(4319, 0),  

 
 

(4320, 0),  

 
 

(4321, 39),  

 
 

(4322, 0),  

 
 

(4323, 70),  

 
 

(4324, 0),  

 
 

(4325, 0),  

 
 

(4326, 19),  

 
 

(4327, 0),  

 
 

(4328, 0),  

 
 

(4329, 83),  

 
 

(4330, 0),  

 
 

(4331, 10),  

 
 

(4332, 25),  

 
 

(4333, 0),  

 
 

(4334, 103),  

 
 

(4335, 0),  

 
 

(4336, 0),  

 
 

(4337, 0),  

 
 

(4338, 0),  

 
 

(4339, 72),  

 
 

(4340, 109),  

 
 

(4341, 97),  

 
 

(4342, 0),  

 
 

(4343, 0),  

 
 

(4344, 0),  

 
 

(4345, 0),  

 
 

(4346, 120),  

 
 

(4347, 0),  

 
 

(4348, 0),  

 
 

(4349, 0),  

 
 

(4350, 42),  

 
 

(4351, 0),  

 
 

(4352, 0),  

 
 

(4353, 0),  

 
 

(4354, 0),  

 
 

(4355, 0),  

 
 

(4356, 0),  

 
 

(4357, 0),  

 
 

(4358, 77),  

 
 

(4359, 0),  

 
 

(4360, 0),  

 
 

(4361, 64),  

 
 

(4362, 0),  

 
 

(4363, 0),  

 
 

(4364, 0),  

 
 

(4365, 0),  

 
 

(4366, 0),  

 
 

(4367, 0),  

 
 

(4368, 22),  

 
 

(4369, 174),  

 
 

(4370, 0),  

 
 

(4371, 0),  

 
 

(4372, 0),  

 
 

(4373, 0),  

 
 

(4374, 0),  

 
 

(4375, 0),  

 
 

(4376, 0),  

 
 

(4377, 58),  

 
 

(4378, 110),  

 
 

(4379, 128),  

 
 

(4380, 0),  

 
 

(4381, 160),  

 
 

(4382, 0),  

 
 

(4383, 0),  

 
 

(4384, 122),  

 
 

(4385, 125),  

 
 

(4386, 0),  

 
 

(4387, 46),  

 
 

(4388, 0),  

 
 

(4389, 151),  

 
 

(4390, 102),  

 
 

(4391, 0),  

 
 

(4392, 0),  

 
 

(4393, 150),  

 
 

(4394, 0),  

 
 

(4395, 0),  

 
 

(4396, 0),  

 
 

(4397, 0),  

 
 

(4398, 162),  

 
 

(4399, 133),  

 
 

(4400, 0),  

 
 

(4401, 49),  

 
 

(4402, 0),  

 
 

(4403, 0),  

 
 

(4404, 0),  

 
 

(4405, 0),  

 
 

(4406, 0),  

 
 

(4407, 0),  

 
 

(4408, 0),  

 
 

(4409, 0),  

 
 

(4410, 0),  

 
 

(4411, 0),  

 
 

(4412, 0),  

 
 

(4413, 0),  

 
 

(4414, 0),  

 
 

(4415, 0),  

 
 

(4416, 0),  

 
 

(4417, 0),  

 
 

(4418, 37),  

 
 

(4419, 0),  

 
 

(4420, 148),  

 
 

(4421, 0),  

 
 

(4422, 0),  

 
 

(4423, 0),  

 
 

(4424, 146),  

 
 

(4425, 0),  

 
 

(4426, 0),  

 
 

(4427, 134),  

 
 

(4428, 0),  

 
 

(4429, 4),  

 
 

(4430, 0),  

 
 

(4431, 0),  

 
 

(4432, 0),  

 
 

(4433, 0),  

 
 

(4434, 0),  

 
 

(4435, 0),  

 
 

(4436, 0),  

 
 

(4437, 0),  

 
 

(4438, 99),  

 
 

(4439, 0),  

 
 

(4440, 0),  

 
 

(4441, 53),  

 
 

(4442, 69),  

 
 

(4443, 0),  

 
 

(4444, 0),  

 
 

(4445, 0),  

 
 

(4446, 0),  

 
 

(4447, 0),  

 
 

(4448, 71),  

 
 

(4449, 62),  

 
 

(4450, 9),  

 
 

(4451, 51),  

 
 

(4452, 0),  

 
 

(4453, 0),  

 
 

(4454, 0),  

 
 

(4455, 0),  

 
 

(4456, 0),  

 
 

(4457, 0),  

 
 

(4458, 0),  

 
 

(4459, 0),  

 
 

(4460, 0),  

 
 

(4461, 0),  

 
 

(4462, 0),  

 
 

(4463, 0),  

 
 

(4464, 52),  

 
 

(4465, 0),  

 
 

(4466, 0),  

 
 

(4467, 47),  

 
 

(4468, 0),  

 
 

(4469, 0),  

 
 

(4470, 0),  

 
 

(4471, 0),  

 
 

(4472, 0),  

 
 

(4473, 0),  

 
 

(4474, 0),  

 
 

(4475, 0),  

 
 

(4476, 0),  

 
 

(4477, 0),  

 
 

(4478, 54),  

 
 

(4479, 0),  

 
 

(4480, 56),  

 
 

(4481, 40),  

 
 

(4482, 117),  

 
 

(4483, 0),  

 
 

(4484, 0),  

 
 

(4485, 0),  

 
 

(4486, 0),  

 
 

(4487, 0),  

 
 

(4488, 168),  

 
 

(4489, 0),  

 
 

(4490, 0),  

 
 

(4491, 0),  

 
 

(4492, 0),  

 
 

(4493, 0),  

 
 

(4494, 0),  

 
 

(4495, 0),  

 
 

(4496, 24),  

 
 

(4497, 0),  

 
 

(4498, 75),  

 
 

(4499, 34),  

 
 

(4500, 0),  

 
 

(4501, 140),  

 
 

(4502, 0),  

 
 

(4503, 108),  

 
 

(4504, 0),  

 
 

(4505, 0),  

 
 

(4506, 153),  

 
 

(4507, 115),  

 
 

(4508, 0),  

 
 

(4509, 0),  

 
 

(4510, 74),  

 
 

(4511, 138),  

 
 

(4512, 0),  

 
 

(4513, 82),  

 
 

(4514, 0),  

 
 

(4515, 136),  

 
 

(4516, 0),  

 
 

(4517, 0),  

 
 

(4518, 147),  

 
 

(4519, 0),  

 
 

(4520, 145),  

 
 

(4521, 0),  

 
 

(4522, 0),  

 
 

(4523, 0),  

 
 

(4524, 0),  

 
 

(4525, 0),  

 
 

(4526, 0),  

 
 

(4527, 0),  

 
 

(4528, 165),  

 
 

(4529, 0),  

 
 

(4530, 167),  

 
 

(4531, 0),  

 
 

(4532, 164),  

 
 

(4533, 20),  

 
 

(4534, 0),  

 
 

(4535, 0),  

 
 

(4536, 0),  

 
 

(4537, 68),  

 
 

(4538, 173),  

 
 

(4539, 6),  

 
 

(4540, 0),  

 
 

(4541, 0),  

 
 

(4542, 0),  

 
 

(4543, 0),  

 
 

(4544, 45),  

 
 

(4545, 0),  

 
 

(4546, 0),  

 
 

(4547, 0),  

 
 

(4548, 88),  

 
 

(4549, 0),  

 
 

(4550, 0),  

 
 

(4551, 0),  

 
 

(4552, 7),  

 
 

(4553, 5),  

 
 

(4554, 87),  

 
 

(4555, 48),  

 
 

(4556, 123),  

 
 

(4557, 0),  

 
 

(4558, 0),  

 
 

(4559, 0),  

 
 

(4560, 0),  

 
 

(4561, 0),  

 
 

(4562, 43),  

 
 

(4563, 0),  

 
 

(4564, 95),  

 
 

(4565, 67),  

 
 

(4566, 0),  

 
 

(4567, 0),  

 
 

(4568, 0),  

 
 

(4569, 0),  

 
 

(4570, 0),  

 
 

(4571, 81);  

 
 

 

 
 

 
 

 

 

 

   

   

 

   

 

   

 

  

 

 

 

   

 

   

 

 

  

 

 

   

 